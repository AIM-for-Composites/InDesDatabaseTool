# Main-Space update kit — "Recently Added" page + ADDED column

Rebased onto **Tejaswi's latest code** (Space commit `970a5b6`, Aug 11 14:09 UTC).
This supersedes the old `hf_space_additions/` folder in the project directory.

Target: https://huggingface.co/spaces/aim4composites/MaterialsDatabase

⚠️ **Before applying, check nothing moved again**: open the Space → Files →
commit history. If the latest commit is still `970a5b6` (or only touched files
not listed below), apply directly. If `Categorized_Search.py` changed again,
use the 3 small edits in `main_space_recently_added.diff` as a guide — they are
anchor-based and easy to re-place by hand.

## What it adds

1. **Recently Added page** — newest ingested documents, verified-property
   counts, and clickable DOI links (provenance from the agent's registry when
   the agent Space is live).
2. **ADDED column** in the Categorized Search materials table — newest
   materials sort to the top, rows ≤14 days old get a 🆕 tag, legacy rows show
   "—" and sink to the bottom.

## Apply via the HF web UI (4 commits, ~5 minutes)

All four files in this folder are **complete replacements** taken from the
patched clone — every commit is revertible via the Space's file history.

| # | File in Space | Action |
|---|---|---|
| 1 | `page_files/Recently_Added.py` | **Add file → Upload file** → upload the `Recently_Added.py` from this folder |
| 2 | `data_loader.py` | Edit → replace contents with this folder's `data_loader.py` (two changes: `extracted_at` added to the column list + SELECT, and the **publish gate** `WHERE COALESCE(status,'ok') = 'ok'` on the SELECT so quarantined / figure-estimate rows never reach Categorized Search; falls back to the unfiltered SELECT with a logged warning if the DB has no `status` column) |
| 3 | `page_files/Categorized_Search.py` | Edit → replace with this folder's `Categorized_Search.py` (3 edits: meta block sorts by `extracted_at`; table gets the Added column; column_config gets ADDED) |
| 4 | `app.py` | Edit → replace with this folder's `app.py` (one line: the Recently Added page in the nav) |

The Space rebuilds (~2–4 min) after each commit; you can also batch all four
in one commit via git:

```bash
git clone https://huggingface.co/spaces/aim4composites/MaterialsDatabase
cp Recently_Added.py MaterialsDatabase/page_files/
cp data_loader.py Categorized_Search.py app.py MaterialsDatabase/  # CS goes to page_files/
cd MaterialsDatabase && git add -A && git commit -m "Recently Added page + ADDED column" && git push
```

`main_space_recently_added.diff` is the exact unified diff of all four changes
for review / manual application.

## Safe-by-design

- If the pipeline/agent has never run, Recently Added shows a friendly empty
  state and the ADDED column shows "—" — nothing errors.
- The `extracted_at` column already exists in the RDS tables (added by
  `pg_migrate.py --apply` during the July pipeline runs; Tejaswi's
  `category_push.py` also writes it), so the new SELECT is compatible with
  both ingestion paths.
- The `status` column also already exists (same `pg_migrate.py --apply`);
  legacy rows have it NULL and are treated as `ok`, so nothing that is
  visible today disappears — only rows the ingester explicitly flagged.
- Nothing here touches Tejaswi's mapper5 / category_push / Upload flow.
