"""Recently Added — newest documents ingested by the autonomous pipeline.

Reads the same three material tables the rest of the app uses (plus, when
present, the agent's DOI registry for provenance links). Safe if the pipeline
has never run: shows a friendly empty state instead of erroring.
"""
import pandas as pd
import streamlit as st

from db import fetch_all

st.title("🆕 Recently Added")

UNION = """
    SELECT source_pdf, material_abbreviation, material_class, status, extracted_at
    FROM "Polymers" WHERE source_pdf IS NOT NULL
    UNION ALL
    SELECT source_pdf, material_abbreviation, material_class, status, extracted_at
    FROM "Fibers" WHERE source_pdf IS NOT NULL
    UNION ALL
    SELECT source_pdf, material_abbreviation, material_class, status, extracted_at
    FROM "Composites_materials" WHERE source_pdf IS NOT NULL
"""

ROLLUP = f"""
    SELECT source_pdf,
           max(extracted_at)                                        AS added,
           count(*)                                                 AS properties,
           count(*) FILTER (WHERE COALESCE(status,'ok') = 'ok')     AS verified,
           string_agg(DISTINCT material_abbreviation, ', ')         AS materials,
           string_agg(DISTINCT material_class, ', ')                AS classes
    FROM ({UNION}) t
    GROUP BY source_pdf
    ORDER BY added DESC NULLS LAST
    LIMIT 100
"""


@st.cache_data(ttl=300)
def load_rollup() -> pd.DataFrame:
    try:
        rows = fetch_all(ROLLUP)
    except Exception:
        return pd.DataFrame()
    return pd.DataFrame(rows, columns=["source_pdf", "added", "properties",
                                       "verified", "materials", "classes"])


@st.cache_data(ttl=300)
def load_provenance() -> pd.DataFrame:
    try:
        rows = fetch_all(
            "SELECT filename, doi, title, source FROM agent_doi_seen")
    except Exception:
        return pd.DataFrame()
    return pd.DataFrame(rows, columns=["filename", "doi", "title", "source"])


df = load_rollup()
if df.empty:
    st.info("Nothing here yet — as soon as the ingestion pipeline publishes "
            "new documents, they will appear on this page, newest first.")
    st.stop()

prov = load_provenance()
if not prov.empty:
    df = df.merge(prov, how="left", left_on="source_pdf", right_on="filename")
    df["doi"] = df["doi"].fillna("").map(
        lambda d: f"https://doi.org/{d}" if d else "")
else:
    df["doi"], df["title"], df["source"] = "", "", ""

df["added"] = df["added"].astype(str).str.slice(0, 16).str.replace("T", " ")
fresh_cutoff = (pd.Timestamp.now(tz='UTC') - pd.Timedelta(days=14)).strftime("%Y-%m-%d")
df["fresh"] = df["added"] >= fresh_cutoff

c1, c2, c3 = st.columns(3)
c1.metric("Source documents", len(df))
c2.metric("Verified property rows", int(df["verified"].sum()))
c3.metric("New in last 14 days", int(df["fresh"].sum()))

show = df[["added", "source_pdf", "title", "materials", "classes",
           "properties", "verified", "doi", "source"]].copy()
show.insert(0, "", df["fresh"].map(lambda f: "🆕" if f else ""))
st.dataframe(
    show,
    column_config={
        "added": "Added (UTC)",
        "source_pdf": "PDF",
        "title": "Paper / datasheet title",
        "properties": st.column_config.NumberColumn("Props"),
        "verified": st.column_config.NumberColumn("Verified"),
        "doi": st.column_config.LinkColumn("DOI"),
    },
    hide_index=True, width="stretch", height=520)

st.caption("Verified = rows with status 'ok' — grounded in the source PDF, "
           "unit-sane, and plausibility-checked by the pipeline. Flagged rows "
           "are quarantined for review and excluded from these counts.")
