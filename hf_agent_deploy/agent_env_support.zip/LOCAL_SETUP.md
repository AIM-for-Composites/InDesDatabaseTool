# Running the agent on your own machine

The Space gets its settings from **Space → Settings → Variables and secrets**,
which Hugging Face injects into the container as environment variables. A
laptop has nothing doing that injection, so the code now reads a `.env` file
instead (`envfile.py`). Anything already in your environment still wins, so
this changes nothing about how the Space behaves.

You need: **Python 3.11+**, **PostgreSQL 14+**, and your **own** Gemini API key.

---

## 1. Get the code

```bash
git clone https://huggingface.co/spaces/aim4composites/AutonomousAgent
cd AutonomousAgent
pip install -r requirements.txt
```

## 2. Start a local Postgres

Run your own database. Do not point a development checkout at the shared RDS
instance: the agent writes to it, and a bad local run would land in the team's
data.

- **Windows / macOS**: install PostgreSQL from postgresql.org (or
  `brew install postgresql@16`), start it, and remember the password you set
  for the `postgres` user.
- Everything else is created for you in step 5.

## 3. Create your `.env`

```bash
cp .env.example .env      # Windows: copy .env.example .env
```

Then open `.env` and fill in the `<angle bracket>` placeholders — your local
Postgres password, and a Gemini key you mint yourself at
<https://aistudio.google.com/apikey> (the free tier is enough).

> **The file must be named exactly `.env`.** Two Windows traps:
> Notepad silently saves it as `.env.txt` unless you pick *All Files* in the
> Save-as dialog, and File Explorer hides the extension so it still *looks*
> right (turn on View → Show → File name extensions). If you write the file
> with PowerShell's `>` redirect you get UTF-16, which most tools cannot read.
> `envfile.py` detects all three and tells you.

`.env` is git-ignored. Never commit it, and never send a filled-in one to
anyone — including a teammate who asks. Each person fills in their own.

## 4. Check what the code can actually see

```bash
python envfile.py
```

This prints which file was found, which keys came out of it, and what is still
missing. Secrets are masked, so the output is safe to paste into a chat when
you want help.

## 5. Create the schema

```bash
python local_bootstrap.py
```

Creates the database, the three material tables, every hardening column, the
dedup indexes and the `agent_*` bookkeeping tables — all empty. Re-running it
is safe. `python local_bootstrap.py --check` reports without changing
anything. It refuses to run against a non-local host unless you pass
`--force`.

## 6. Run it

```bash
streamlit run app.py
```

Then open <http://localhost:8501>. Unlock **Run Control** with the
`AGENT_ADMIN_PASSWORD` you set in your own `.env` and trigger a cycle from
there. `AGENT_AUTOSTART=false` keeps it from crawling on its own while you are
developing.

## 7. Prove the whole path works (optional)

```bash
python test_e2e.py
```

Runs two full agent cycles against your local database with network discovery
and Gemini stubbed out — 16 checks, no API cost.

---

## Troubleshooting

| What you see | What it means | Fix |
|---|---|---|
| `Postgres config incomplete — missing DB_HOST, …` | Nothing supplied the settings | `python envfile.py` — it says whether a `.env` was found and which keys it contains |
| "Database not configured." in the app | Same, shown in the UI | Same |
| `.env` found but keys missing | The file parsed, but does not define them | Compare against `.env.example`; every line is `KEY=value` |
| `Found .env.txt … must be named exactly ".env"` | The Windows extension trap | Rename it; turn on file-name extensions in Explorer |
| `is UTF-16 encoded` | Written by PowerShell `>` | Re-save as UTF-8 (VS Code: bottom-right encoding picker) |
| `connection refused` | Postgres is not running, or a different port | Start the service; check `DB_PORT` |
| `password authentication failed` | `DB_USER`/`DB_PASSWORD` do not match the server | Fix them in `.env` |
| `database "aim_agent" does not exist` | Schema step not run yet | `python local_bootstrap.py` |
| `SSL connection has been closed` on localhost | `DB_SSLMODE=require` against a local server | Set `DB_SSLMODE=prefer` |
| App loads but extraction does nothing | No Gemini key | Add `GEMINI_API_KEY`; crawling works without it |

## A note on credentials

Nobody should send anybody a filled-in `.env`. API keys are per-person and
billable, and a chat message gets forwarded, backed up and screenshotted. Mint
your own Gemini key, use your own local Postgres password, and if you need
access to shared data, ask for a read-only database role rather than the
credentials the agent runs with.
