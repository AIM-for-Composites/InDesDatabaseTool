"""AIM Composites — Autonomous Ingestion Agent Space.

Streamlit shell: navigation + one-time boot (schema, query seeding, background
scheduler). The agent itself lives in agent/orchestrator.py and keeps running
whether or not anyone is viewing the app.
"""
import logging

# Before anything reads os.environ: on a laptop the secrets come from a .env,
# on HF Spaces they are already in the environment and take precedence.
try:
    import envfile as _envfile
    _ENV = _envfile.load_env_file()
except ImportError:  # pragma: no cover
    _envfile, _ENV = None, None

import streamlit as st

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s %(message)s")

if _ENV is not None:
    _log = logging.getLogger("agent.env")
    if _ENV.path:
        _log.info("loaded .env from %s (%d keys: %s)",
                  _ENV.path, len(_ENV.applied), ", ".join(_ENV.applied))
    for _w in _ENV.warnings:
        _log.warning("env: %s", _w)

st.set_page_config(
    page_title="AIM Autonomous Agent",
    page_icon="🤖",
    layout="wide",
)

from agent.ui_common import boot  # noqa: E402

boot()  # idempotent: agent schema, default queries, scheduler sync

pages = {
    "": [
        st.Page("page_files/Dashboard.py", title="Dashboard", icon="📊", default=True),
        st.Page("page_files/Run_Control.py", title="Run Control", icon="🎛️"),
        st.Page("page_files/Recently_Added.py", title="Recently Added", icon="🆕"),
        st.Page("page_files/Database.py", title="Database", icon="🗄️"),
        st.Page("page_files/Review_Queue.py", title="Review Queue", icon="🔍"),
        st.Page("page_files/Logs.py", title="Runs & Logs", icon="📜"),
    ]
}

st.navigation(pages, position="top").run()
