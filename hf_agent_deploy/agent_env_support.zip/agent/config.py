"""Central configuration for the autonomous agent Space.

Everything is read from the environment (HF Space secrets/variables) with
safe defaults. Locally there is no Space to set those, so a ``.env`` file
next to ``app.py`` is loaded first (see envfile.py) — the environment always
wins, so this changes nothing when running on HF. Runtime-tunable knobs (interval, caps, autonomy on/off) live
in the `agent_state` Postgres table so they survive restarts and are editable
from the Run Control page — the values here are only the first-boot defaults.
"""
from __future__ import annotations

import os
from pathlib import Path

# Load a local .env (no-op on HF Spaces, where the secrets are already in the
# environment and win regardless). Must happen before anything below reads
# os.environ.
try:
    import envfile as _envfile
except ImportError:  # pragma: no cover
    _envfile = None
    ENV_FILE_RESULT = None
else:
    ENV_FILE_RESULT = _envfile.load_env_file()


def _f(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, "") or default)
    except ValueError:
        return default


def _i(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, "") or default)
    except ValueError:
        return default


def _b(name: str, default: bool) -> bool:
    raw = (os.environ.get(name) or "").strip().lower()
    if not raw:
        return default
    return raw in ("1", "true", "yes", "on")


# --- credentials ------------------------------------------------------------
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or ""
ADMIN_PASSWORD = os.environ.get("AGENT_ADMIN_PASSWORD", "")          # empty → controls locked
CONTACT_EMAIL = os.environ.get("CONTACT_EMAIL", "mathias.heider@gmail.com")

# --- working dirs (ephemeral on HF Spaces — durable state lives in Postgres) -
WORK_DIR = Path(os.environ.get("AGENT_WORK_DIR", "/tmp/agent_work"))
PDF_DIR = WORK_DIR / "pdfs"
REVIEW_CSV = WORK_DIR / "review_queue.csv"

# --- first-boot defaults for runtime-tunable knobs (agent_state overrides) --
DEFAULTS = {
    "autonomy": _b("AGENT_AUTOSTART", False),      # start crawling on boot?
    "interval_hours": _f("AGENT_INTERVAL_HOURS", 6.0),
    "max_new_pdfs_per_cycle": _i("AGENT_MAX_PDFS", 5),
    "max_per_query": _i("AGENT_MAX_PER_QUERY", 4),
    "queries_per_cycle": _i("AGENT_QUERIES_PER_CYCLE", 3),
    "use_arxiv": True,
    "use_openalex": True,
    "use_semantic_scholar": False,   # free tier 429s constantly; enable with S2_API_KEY
    "expand_queries": False,         # let Gemini propose new queries when yields drop
    "min_relevance_score": 4,        # pdf_crawler.MIN_SCORE
}

STATE_KEYS = list(DEFAULTS)

# Safety rails (not runtime-tunable).
HARD_MAX_PDFS_PER_CYCLE = _i("AGENT_HARD_MAX_PDFS", 25)
CYCLE_STALE_MINUTES = 90             # a 'running' flag older than this is considered crashed


REQUIRED_DB_VARS = ("DB_HOST", "DB_NAME", "DB_USER", "DB_PASSWORD")


def missing_db_vars() -> list[str]:
    """Which Postgres settings are absent. Empty list == configured.

    A DATABASE_URL that psycopg cannot parse counts as missing rather than
    configured: otherwise the UI reports "configured but not reachable" for a
    connection that was never attempted.
    """
    url = os.environ.get("DATABASE_URL", "").strip()
    if url:
        try:
            import psycopg
            psycopg.conninfo.conninfo_to_dict(url)
        except ImportError:
            return []
        except Exception:
            return ["DATABASE_URL (set, but not a valid connection string)"]
        return []
    return [v for v in REQUIRED_DB_VARS if not os.environ.get(v)]


def env_file_path() -> str:
    """The .env this process loaded, or "" if none was found."""
    if ENV_FILE_RESULT is None or ENV_FILE_RESULT.path is None:
        return ""
    return str(ENV_FILE_RESULT.path)


def setup_hint() -> str:
    """One actionable paragraph explaining how to supply what is missing."""
    gaps = missing_db_vars()
    if not gaps:
        return ""
    listed = ", ".join(gaps)
    found = env_file_path()
    where = f"loaded .env: {found}" if found else "no .env file was found"
    return (
        f"Missing configuration: {listed} ({where}).\n"
        "  - On Hugging Face: Space -> Settings -> Variables and secrets.\n"
        "  - Locally: copy .env.example to .env next to app.py, fill it in, "
        "then run `python envfile.py` to verify.\n"
        "  See LOCAL_SETUP.md for the full walkthrough."
    )


def ensure_dirs() -> None:
    PDF_DIR.mkdir(parents=True, exist_ok=True)
