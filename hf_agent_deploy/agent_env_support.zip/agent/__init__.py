"""AIM Composites autonomous ingestion agent package."""

# A local checkout has no Hugging Face Space to inject secrets into the
# process, so pull a .env into os.environ before any submodule reads it.
# Values already present in the environment are never overwritten, which
# keeps the real Space secrets authoritative in the cloud.
try:
    from envfile import load_env_file as _load_env_file
except ImportError:  # a partial copy without envfile.py still imports fine
    pass
else:
    _load_env_file()
