"""Zero-dependency ``.env`` loader for the AIM autonomous agent.

Why this module exists
----------------------
On Hugging Face, the Space injects its secrets directly into the process
environment, so every module here has always just read ``os.environ``. On a
laptop nothing injects them, which is why a fresh local checkout fails with
"Postgres config incomplete" or "GEMINI_API_KEY is not set" *even when a
``.env`` file is sitting right next to ``app.py``* — nothing was ever reading
that file.

This module reads it, and copies the values into ``os.environ`` **without
overwriting anything already set**, so:

  * on HF Spaces  -> the real Space secrets always win (a ``.env`` is normally
    absent there anyway, and is git-ignored so it can never be pushed)
  * on a laptop   -> the ``.env`` supplies everything the Space would have

Stdlib only, on purpose: adding a dependency here would force a Space rebuild
and could break a deploy over a convenience feature.

Self-check
----------
    python envfile.py

prints which file was found, which keys came out of it, and which required
variables are still missing. Values are always masked — the output is safe to
paste into a chat when asking for help.
"""

from __future__ import annotations

import os
import sys
from pathlib import Path
from typing import Iterable, NamedTuple

__all__ = ["load_env_file", "find_env_file", "LoadResult", "report"]

#: Variables the agent needs before it can talk to Postgres.
REQUIRED_DB = ("DB_HOST", "DB_NAME", "DB_USER", "DB_PASSWORD")
#: Present-but-optional; the app runs degraded without them.
RECOMMENDED = ("GEMINI_API_KEY", "AGENT_ADMIN_PASSWORD")
#: Never printed, even masked, unless the value is empty.
_SECRETISH = ("PASSWORD", "KEY", "TOKEN", "SECRET", "DATABASE_URL")

_LOADED_FROM: Path | None = None
_CACHED: "LoadResult | None" = None


class LoadResult(NamedTuple):
    path: Path | None          # the file that was read, if any
    applied: tuple[str, ...]   # keys copied into os.environ
    skipped: tuple[str, ...]   # keys already set in the environment (env wins)
    warnings: tuple[str, ...]  # human-readable problems worth surfacing


# ---------------------------------------------------------------------------
# Finding the file
# ---------------------------------------------------------------------------

def find_env_file(start: str | os.PathLike | None = None) -> tuple[Path | None, list[str]]:
    """Locate a ``.env``. Returns (path_or_None, warnings).

    Search order:
      1. ``$AGENT_ENV_FILE`` (explicit override; may be any filename)
      2. ``.env`` in this repo's root
      3. ``.env`` in the current working directory, then each parent, up to 4
         levels — so ``python agent/foo.py`` from a subfolder still works.

    Common near-misses (``.env.txt`` from Windows Notepad, a stray ``env``
    without the dot, only ``.env.example`` present) are reported as warnings
    rather than silently ignored: they are the usual cause of "it says it
    can't find my .env".
    """
    warnings: list[str] = []

    override = os.environ.get("AGENT_ENV_FILE", "").strip()
    if override:
        p = Path(override).expanduser()
        if p.is_file():
            return p, warnings
        warnings.append(f"AGENT_ENV_FILE points at {p} but no such file exists.")

    here = Path(__file__).resolve().parent
    candidates: list[Path] = [here]
    cwd = Path(start or Path.cwd()).resolve()
    candidates.append(cwd)
    candidates.extend(list(cwd.parents)[:4])

    seen: set[Path] = set()
    near_misses: list[Path] = []
    for folder in candidates:
        if folder in seen:
            continue
        seen.add(folder)
        target = folder / ".env"
        if target.is_file():
            return target, warnings
        for wrong in (".env.txt", ".env.local.txt", "env", "env.txt", ".ENV"):
            candidate = folder / wrong
            if candidate.is_file():
                near_misses.append(candidate)

    for miss in near_misses:
        warnings.append(
            f"Found {miss.name} in {miss.parent} but the file must be named "
            f'exactly ".env". On Windows, Notepad appends ".txt" unless you '
            'pick "All Files" in the Save-as dialog; File Explorer hides the '
            "extension by default (View -> Show -> File name extensions)."
        )
    if not near_misses and not warnings:
        example = here / ".env.example"
        if example.is_file():
            warnings.append(
                f"No .env found. Copy {example} to {here / '.env'} and fill it in."
            )
    return None, warnings


# ---------------------------------------------------------------------------
# Reading the file
# ---------------------------------------------------------------------------

def _read_text(path: Path) -> tuple[str, list[str]]:
    """Decode a .env written by any of the editors people actually use."""
    warnings: list[str] = []
    raw = path.read_bytes()
    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        # PowerShell 5's `>` redirect writes UTF-16LE. Perfectly readable in
        # Notepad, complete gibberish to every .env parser on earth.
        warnings.append(
            f"{path.name} is UTF-16 encoded (usually from PowerShell's '>' "
            "redirect). It was decoded, but re-save it as UTF-8 to avoid "
            "trouble with other tools."
        )
        text = raw.decode("utf-16")
    else:
        text = raw.decode("utf-8-sig", errors="replace")  # utf-8-sig eats the BOM
    return text.replace("\r\n", "\n").replace("\r", "\n"), warnings


def _unquote(value: str) -> tuple[str, str | None]:
    """Strip quotes/comments from a raw value. Returns (value, warning)."""
    value = value.strip()
    if not value:
        return "", None

    if value[0] in ("'", '"'):
        quote = value[0]
        end = value.find(quote, 1)
        # In double quotes a backslash escapes the quote; keep looking.
        while end > 0 and quote == '"' and value[end - 1] == "\\":
            end = value.find(quote, end + 1)
        if end == -1:
            return value, ("value starts with %s but never closes it; "
                           "taken literally" % quote)
        inner = value[1:end]
        if quote == '"':
            inner = (inner.replace("\\n", "\n")
                          .replace("\\t", "\t")
                          .replace('\\"', '"'))
        trailing = value[end + 1:].strip()
        if trailing and not trailing.startswith("#"):
            return inner, ("ignored %r after the closing quote" % trailing[:20])
        return inner, None

    # Unquoted: honour a trailing ' # comment', but only when whitespace
    # precedes the '#' — passwords legitimately contain '#'.
    for i in range(1, len(value)):
        if value[i] == "#" and value[i - 1] in " \t":
            return value[:i].rstrip(), None
    return value, None


def parse_env(text: str) -> tuple[dict[str, str], list[str]]:
    """Parse .env text into a dict. Returns (values, warnings)."""
    values: dict[str, str] = {}
    warnings: list[str] = []
    for lineno, line in enumerate(text.split("\n"), start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped.lower().startswith("export "):
            stripped = stripped[7:].lstrip()
        if "=" not in stripped:
            if ":" in stripped:
                warnings.append(
                    f"line {lineno}: looks like YAML ('{stripped[:40]}'). "
                    "A .env uses KEY=value, one per line."
                )
            else:
                warnings.append(f"line {lineno}: no '=' found, ignored.")
            continue
        key, _, value = stripped.partition("=")
        key = key.strip()
        if not key:
            warnings.append(f"line {lineno}: empty key, ignored.")
            continue
        if not all(c.isalnum() or c == "_" for c in key):
            warnings.append(
                f"line {lineno}: key {key!r} has characters other than "
                "letters/digits/underscore; it will not be readable as an "
                "environment variable."
            )
            continue
        parsed, warning = _unquote(value)
        if warning:
            warnings.append(f"line {lineno} ({key}): {warning}")
        values[key] = parsed
    return values, warnings


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def load_env_file(path: str | os.PathLike | None = None,
                  override: bool = False,
                  reload: bool = False) -> LoadResult:
    """Load a ``.env`` into ``os.environ``. Idempotent and never raises.

    ``override=False`` (the default) means a variable already present in the
    environment is left alone — that is what keeps HF Space secrets
    authoritative in the cloud while a laptop still gets its values from file.

    The first call in a process wins and its result is cached: several modules
    call this defensively, and re-running it would report every key as
    "already in the environment" (true, but only because of the first call).
    Pass ``reload=True`` to genuinely re-read the file.
    """
    global _LOADED_FROM, _CACHED

    if _CACHED is not None and not reload and path is None:
        return _CACHED

    warnings: list[str] = []
    if path is not None:
        target = Path(path).expanduser()
        if not target.is_file():
            return LoadResult(None, (), (), (f"{target} does not exist.",))
    else:
        target, warnings = find_env_file()
        if target is None:
            _CACHED = LoadResult(None, (), (), tuple(warnings))
            return _CACHED

    try:
        text, decode_warnings = _read_text(target)
    except OSError as exc:
        return LoadResult(None, (), (), tuple(warnings) + (f"could not read {target}: {exc}",))
    warnings.extend(decode_warnings)

    values, parse_warnings = parse_env(text)
    warnings.extend(parse_warnings)

    applied, skipped = [], []
    for key, value in values.items():
        if not override and os.environ.get(key):
            skipped.append(key)
            continue
        os.environ[key] = value
        applied.append(key)

    placeholders = [k for k, v in values.items() if is_placeholder(v)]
    if placeholders:
        warnings.append(
            "still on placeholder values (edit them): " + ", ".join(sorted(placeholders))
        )

    _LOADED_FROM = target
    result = LoadResult(target, tuple(applied), tuple(skipped), tuple(warnings))
    if path is None:
        _CACHED = result
    return result


def loaded_from() -> Path | None:
    """The .env this process loaded, if any (for diagnostics/logging)."""
    return _LOADED_FROM


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------

_PLACEHOLDER_PREFIXES = ("fill in", "fillin", "your ", "your-", "your_",
                         "changeme", "change me", "todo", "tbd", "xxx",
                         "paste ", "insert ", "replace ")


def is_placeholder(value: str) -> bool:
    """True if a value is obviously still the template text, not a real one."""
    v = value.strip()
    if not v:
        return False
    if v.startswith("<") and v.endswith(">"):
        return True
    return v.lower().startswith(_PLACEHOLDER_PREFIXES)


def _mask(key: str, value: str) -> str:
    """Never reveal a secret. Keys show a 4-char tail so you can tell two keys
    apart; passwords and connection strings show nothing but a length."""
    if not value:
        return "(empty)"
    upper = key.upper()
    if "PASSWORD" in upper or "DATABASE_URL" in upper or "SECRET" in upper:
        return f"set ({len(value)} chars)"
    if any(token in upper for token in ("KEY", "TOKEN")):
        return f"set ({len(value)} chars, ...{value[-4:]})" if len(value) > 8 else "set (short)"
    return value


def missing(names: Iterable[str]) -> list[str]:
    return [n for n in names if not os.environ.get(n)]


def report() -> str:
    """Human-readable config check. Safe to paste into a chat — no secrets."""
    result = load_env_file(reload=True)
    lines = ["AIM agent — environment self-check", "=" * 42]

    if result.path:
        lines.append(f".env file:      {result.path}")
        lines.append(f"keys applied:   {', '.join(result.applied) or '(none)'}")
        if result.skipped:
            lines.append(f"already in env: {', '.join(result.skipped)} (environment wins)")
    else:
        lines.append(".env file:      NOT FOUND")

    lines.append("")
    lines.append("Database:")
    if os.environ.get("DATABASE_URL"):
        lines.append("  DATABASE_URL  set (overrides the DB_* variables)")
        db_missing: list[str] = []
    else:
        db_missing = missing(REQUIRED_DB)
        for name in REQUIRED_DB + ("DB_PORT", "DB_SSLMODE"):
            value = os.environ.get(name, "")
            if is_placeholder(value):
                lines.append(f"!! {name:<14} still template text — fill it in")
            else:
                flag = "  " if value else "!!"
                lines.append(f"{flag} {name:<14} {_mask(name, value)}")

    lines.append("")
    lines.append("Agent:")
    for name in RECOMMENDED + ("AGENT_WORK_DIR", "AGENT_AUTOSTART"):
        value = os.environ.get(name, "")
        if is_placeholder(value):
            lines.append(f"!! {name:<22} still template text — fill it in")
        else:
            lines.append(f"   {name:<22} {_mask(name, value)}")

    if result.warnings:
        lines.append("")
        lines.append("Warnings:")
        lines.extend(f"  - {w}" for w in result.warnings)

    unfilled = sorted(k for k in set(REQUIRED_DB + RECOMMENDED + ("DATABASE_URL",))
                      if is_placeholder(os.environ.get(k, "")))

    lines.append("")
    if db_missing:
        lines.append("RESULT: not ready — missing " + ", ".join(db_missing))
    elif unfilled:
        lines.append("RESULT: not ready — still on template text: "
                     + ", ".join(unfilled)
                     + "\n        Edit those lines in the .env, then re-run this check.")
    elif not os.environ.get("GEMINI_API_KEY") and not os.environ.get("GOOGLE_API_KEY"):
        lines.append("RESULT: database configured; extraction disabled "
                     "(no GEMINI_API_KEY) — crawling still works.")
    else:
        lines.append("RESULT: configuration looks complete.")
    return "\n".join(lines)


if __name__ == "__main__":
    print(report())
    sys.exit(0)
