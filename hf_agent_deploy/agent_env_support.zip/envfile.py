"""Zero-dependency ``.env`` loader for the AIM autonomous agent.

Why this module exists
----------------------
On Hugging Face, the Space injects its secrets directly into the process
environment, so every module here has always just read ``os.environ``. On a
laptop nothing injects them, which is why a fresh local checkout fails with
"Postgres config incomplete" or "GEMINI_API_KEY is not set" *even when a
``.env`` file is sitting right next to ``app.py``* — nothing was ever reading
that file.

This module reads it, and copies the values into ``os.environ`` **without
overwriting anything already set**, so:

  * on HF Spaces  -> the real Space secrets always win (a ``.env`` is normally
    absent there anyway, and is git-ignored so it can never be pushed)
  * on a laptop   -> the ``.env`` supplies everything the Space would have

"Already set" means *present*, including present-and-empty: a Space secret
deliberately blanked to disable a feature is not silently refilled from a file.

Stdlib only, on purpose: adding a dependency here would force a Space rebuild
and could break a deploy over a convenience feature.

Escaping
--------
Values may be quoted. Inside double quotes only ``\\"`` and ``\\\\`` are
escapes — ``\\n`` and ``\\t`` are left alone, because on Windows they appear in
ordinary paths (``C:\\temp\\notes``) far more often than anyone wants a literal
newline in a password. Multi-line values are not supported.

Self-check
----------
    python envfile.py

prints which file was found, which keys came out of it, and which required
variables are still missing. It never prints a value from the file, not even
inside a warning — the output is safe to paste into a chat when asking for
help.
"""

from __future__ import annotations

import os
import sys
import threading
from pathlib import Path
from typing import Iterable, NamedTuple

__all__ = ["load_env_file", "find_env_file", "LoadResult", "report", "loaded_from"]

#: Variables the agent needs before it can talk to Postgres.
REQUIRED_DB = ("DB_HOST", "DB_NAME", "DB_USER", "DB_PASSWORD")
#: Present-but-optional; the app runs degraded without them.
RECOMMENDED = ("GEMINI_API_KEY", "AGENT_ADMIN_PASSWORD")

#: Names whose values are safe to echo in a diagnostic. Everything else is
#: masked. This is an ALLOW-list on purpose: a deny-list of "PASSWORD|KEY|..."
#: lets DB_HOST, DB_USER and DB_NAME — three quarters of a database
#: credential — print in full.
SAFE_TO_PRINT = frozenset({
    "DB_PORT", "DB_SSLMODE", "GEMINI_MODEL", "AGENT_AUTOSTART",
    "AGENT_INTERVAL_HOURS", "AGENT_MAX_PDFS", "AGENT_MAX_PER_QUERY",
    "AGENT_QUERIES_PER_CYCLE", "AGENT_HARD_MAX_PDFS",
})

_LOOPBACK = frozenset({"localhost", "127.0.0.1", "::1", "0:0:0:0:0:0:0:1", "[::1]", ""})

_LOCK = threading.Lock()
_LOADED_FROM: Path | None = None
_CACHED: "LoadResult | None" = None


class LoadResult(NamedTuple):
    path: Path | None          # the file that was read, if any
    applied: tuple[str, ...]   # keys copied into os.environ
    skipped: tuple[str, ...]   # keys already present in the environment
    warnings: tuple[str, ...]  # human-readable problems; never contain values


# ---------------------------------------------------------------------------
# Finding the file
# ---------------------------------------------------------------------------

def _repo_root() -> Path:
    return Path(__file__).resolve().parent


def _describe_non_file(p: Path) -> str | None:
    """Explain a path that exists but is not a readable regular file."""
    try:
        if p.is_dir():
            return f"{p} is a directory, not a file."
        if p.is_symlink() and not p.exists():
            return f"{p} is a symlink pointing at something that does not exist."
        if p.exists() and not os.access(p, os.R_OK):
            return f"{p} exists but is not readable (check its permissions)."
    except OSError:
        return None
    return None


def find_env_file(start: str | os.PathLike | None = None) -> tuple[Path | None, list[str]]:
    """Locate a ``.env``. Returns (path_or_None, warnings).

    Search order:
      1. ``$AGENT_ENV_FILE`` (explicit override; may be any filename)
      2. ``.env`` beside this module — i.e. the repo root, next to ``app.py``
      3. ``.env`` in the current working directory, then upward, stopping at
         the first directory that looks like a project root (contains ``.git``
         or ``pyproject.toml``) and never climbing more than 4 levels.

    The upward walk deliberately stops at a project boundary: without that, a
    stray ``~/.env`` from an unrelated project gets applied to this one with no
    indication. Anything found outside the repo is reported as a warning.

    Common near-misses (``.env.txt`` from Windows Notepad, a stray ``env``
    without the dot, only ``.env.example`` present) are reported too: they are
    the usual cause of "it says it can't find my .env".
    """
    warnings: list[str] = []

    override = os.environ.get("AGENT_ENV_FILE", "").strip()
    if override:
        try:
            p = Path(override).expanduser()
        except (RuntimeError, OSError):
            p = Path(override)
        try:
            if p.is_file():
                return p, warnings
        except OSError:
            pass
        detail = _describe_non_file(p)
        warnings.append(detail or f"AGENT_ENV_FILE points at {p} but no such file exists.")

    here = _repo_root()
    candidates: list[Path] = [here]
    try:
        cwd = Path(start).resolve() if start is not None else Path.cwd()
        candidates.append(cwd)
        for parent in list(cwd.parents)[:4]:
            candidates.append(parent)
            # stop climbing once we are at a project root
            if (parent / ".git").exists() or (parent / "pyproject.toml").exists():
                break
    except (OSError, RuntimeError):
        cwd = here  # cwd was deleted out from under us; the repo dir still works

    seen: set[Path] = set()
    near_misses: list[Path] = []
    for folder in candidates:
        if folder in seen:
            continue
        seen.add(folder)
        target = folder / ".env"
        try:
            is_file = target.is_file()
        except OSError:
            is_file = False
        if is_file:
            if folder != here and folder != cwd:
                warnings.append(
                    f"using a .env from {folder}, which is outside the project "
                    f"folder ({here}). If that is not the one you meant, set "
                    "AGENT_ENV_FILE or put a .env next to app.py."
                )
            return target, warnings
        detail = _describe_non_file(target)
        if detail:
            warnings.append(detail)
        for wrong in (".env.txt", ".env.local.txt", "env", "env.txt", ".ENV"):
            candidate = folder / wrong
            try:
                if candidate.is_file():
                    near_misses.append(candidate)
            except OSError:
                pass

    for miss in near_misses:
        warnings.append(
            f"Found {miss.name} in {miss.parent} but the file must be named "
            f'exactly ".env". On Windows, Notepad appends ".txt" unless you '
            'pick "All Files" in the Save-as dialog; File Explorer hides the '
            "extension by default (View -> Show -> File name extensions)."
        )
    if not near_misses and not warnings:
        example = here / ".env.example"
        try:
            has_example = example.is_file()
        except OSError:
            has_example = False
        if has_example:
            warnings.append(
                f"No .env found. Copy {example} to {here / '.env'} and fill it in."
            )
    return None, warnings


# ---------------------------------------------------------------------------
# Reading the file
# ---------------------------------------------------------------------------

def _read_text(path: Path) -> tuple[str, list[str]]:
    """Decode a .env written by any of the editors people actually use."""
    warnings: list[str] = []
    raw = path.read_bytes()

    def _utf16(codec: str, why: str) -> str:
        warnings.append(
            f"{path.name} is {codec.upper()} encoded ({why}). It was decoded, "
            "but re-save it as UTF-8 to avoid trouble with other tools."
        )
        return raw.decode(codec, errors="replace")

    if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
        # PowerShell 5's `>` redirect writes UTF-16LE. Readable in Notepad,
        # gibberish to every .env parser on earth.
        text = _utf16("utf-16", "usually from PowerShell's '>' redirect")
    elif b"\x00" in raw[:200]:
        # UTF-16 with no BOM: every other byte is NUL.
        codec = "utf-16-le" if raw[1:2] == b"\x00" else "utf-16-be"
        text = _utf16(codec, "no byte-order mark, detected from the NUL bytes")
    else:
        try:
            text = raw.decode("utf-8-sig")  # utf-8-sig eats a BOM if present
        except UnicodeDecodeError:
            text = raw.decode("utf-8-sig", errors="replace")
            warnings.append(
                f"{path.name} is not valid UTF-8; {text.count(chr(0xFFFD))} "
                "character(s) could not be decoded and were replaced. A value "
                "containing them (a password with an accented letter, say) is "
                "now wrong — re-save the file as UTF-8."
            )
    return text.replace("\r\n", "\n").replace("\r", "\n"), warnings


def _expand_escapes(s: str) -> str:
    r"""Expand only ``\"`` and ``\\``. See the module docstring on Windows paths."""
    if "\\" not in s:
        return s
    out: list[str] = []
    i = 0
    while i < len(s):
        if s[i] == "\\" and i + 1 < len(s) and s[i + 1] in ('"', "\\"):
            out.append(s[i + 1])
            i += 2
        else:
            out.append(s[i])
            i += 1
    return "".join(out)


def _unquote(value: str) -> tuple[str, str | None]:
    """Strip quotes/comments from a raw value. Returns (value, warning).

    Warnings never quote the value itself — this output reaches a chat window.
    """
    value = value.strip()
    if not value:
        return "", None

    if value[0] in ("'", '"'):
        quote = value[0]
        end = value.find(quote, 1)
        # In double quotes a backslash escapes the quote; keep looking.
        while end > 0 and quote == '"' and value[end - 1] == "\\":
            end = value.find(quote, end + 1)
        if end == -1:
            return value[1:], ("opening quote is never closed; the quote was "
                               "dropped and the rest taken literally "
                               "(multi-line values are not supported)")
        inner = value[1:end]
        if quote == '"':
            inner = _expand_escapes(inner)
        trailing = value[end + 1:].strip()
        if trailing and not trailing.startswith("#"):
            return inner, (f"ignored {len(trailing)} character(s) after the "
                           "closing quote")
        return inner, None

    # Unquoted: honour a trailing ' # comment', but only when whitespace
    # precedes the '#' — passwords legitimately contain '#'.
    for i in range(1, len(value)):
        if value[i] == "#" and value[i - 1] in " \t":
            return value[:i].rstrip(), ("everything after ' #' was treated as a "
                                        "comment; quote the value to keep it")
    return value, None


def _valid_key(key: str) -> bool:
    if not key or (not key[0].isascii() or not (key[0].isalpha() or key[0] == "_")):
        return False
    return all(c.isascii() and (c.isalnum() or c == "_") for c in key)


def parse_env(text: str) -> tuple[dict[str, str], list[str]]:
    """Parse .env text into a dict. Returns (values, warnings).

    Warnings identify problems by line number and key name only — never by
    value — because they are surfaced in ``report()`` and in the app log.
    """
    values: dict[str, str] = {}
    warnings: list[str] = []
    for lineno, line in enumerate(text.split("\n"), start=1):
        stripped = line.strip()
        if not stripped or stripped.startswith("#"):
            continue
        if stripped[:7].lower() == "export ":
            stripped = stripped[7:].lstrip()
        if "=" not in stripped:
            warnings.append(
                f"line {lineno}: no '=' found, ignored. A .env holds one "
                "KEY=value per line (not YAML, not a connection URL on its own)."
            )
            continue
        key, _, value = stripped.partition("=")
        key = key.strip()
        if not key:
            warnings.append(f"line {lineno}: empty key, ignored.")
            continue
        if not _valid_key(key):
            warnings.append(
                f"line {lineno}: key {key!r} is not a usable environment "
                "variable name (letters, digits and underscore only, not "
                "starting with a digit), ignored."
            )
            continue
        if key != key.upper():
            warnings.append(
                f"line {lineno}: key {key!r} is lower-case; this code reads "
                f"{key.upper()!r}, so the value will be ignored on macOS/Linux."
            )
        parsed, warning = _unquote(value)
        if warning:
            warnings.append(f"line {lineno} ({key}): {warning}")
        if "\x00" in parsed:
            warnings.append(
                f"line {lineno} ({key}): value contains a NUL byte and cannot "
                "be an environment variable; ignored. The file is probably "
                "mis-encoded."
            )
            continue
        if key in values and values[key] != parsed:
            warnings.append(
                f"line {lineno} ({key}): redefined with a different value; "
                "the last one wins."
            )
        values[key] = parsed
    return values, warnings


# ---------------------------------------------------------------------------
# Public entry point
# ---------------------------------------------------------------------------

def _load_uncached(path: str | os.PathLike | None, override: bool) -> LoadResult:
    warnings: list[str] = []
    if path is not None:
        try:
            target = Path(path).expanduser()
        except (RuntimeError, OSError):
            target = Path(path)
        try:
            if not target.is_file():
                return LoadResult(None, (), (), (_describe_non_file(target)
                                                or f"{target} does not exist.",))
        except OSError as exc:
            return LoadResult(None, (), (), (f"cannot inspect {target}: {exc}",))
    else:
        target, warnings = find_env_file()
        if target is None:
            return LoadResult(None, (), (), tuple(warnings))

    try:
        text, decode_warnings = _read_text(target)
    except (OSError, UnicodeError) as exc:
        return LoadResult(None, (), (), tuple(warnings) + (f"could not read {target}: {exc}",))
    warnings.extend(decode_warnings)

    values, parse_warnings = parse_env(text)
    warnings.extend(parse_warnings)

    applied, skipped = [], []
    for key, value in values.items():
        # `key in os.environ`, not `.get(key)`: a variable set to the empty
        # string is still set, and a blanked Space secret must stay blank.
        if not override and key in os.environ:
            skipped.append(key)
            continue
        try:
            os.environ[key] = value
        except ValueError as exc:  # embedded NUL and friends
            warnings.append(f"{key}: could not be set ({exc}).")
            continue
        applied.append(key)

    placeholders = [k for k, v in values.items() if is_placeholder(v)]
    if placeholders:
        warnings.append(
            "still on template text (edit these): " + ", ".join(sorted(placeholders))
        )

    return LoadResult(target, tuple(applied), tuple(skipped), tuple(warnings))


def load_env_file(path: str | os.PathLike | None = None,
                  override: bool = False,
                  reload: bool = False) -> LoadResult:
    """Load a ``.env`` into ``os.environ``. Idempotent, and never raises.

    ``override=False`` (the default) means a variable already present in the
    environment is left alone — that is what keeps HF Space secrets
    authoritative in the cloud while a laptop still gets its values from file.

    The first default call in a process wins and its result is cached: several
    modules call this defensively, and re-running it would report every key as
    "already in the environment" (true, but only because of the first call).
    ``reload=True`` genuinely re-reads without disturbing that cached answer;
    an explicit ``path`` and ``override=True`` also bypass the cache.
    """
    global _LOADED_FROM, _CACHED

    def _attempt() -> LoadResult:
        try:
            return _load_uncached(path, override)
        except Exception as exc:  # the docstring promises this; keep the promise
            return LoadResult(None, (), (), (f"loading the .env failed unexpectedly: {exc!r}",))

    cacheable = path is None and not override and not reload
    if cacheable:
        # The load runs *inside* the lock: two threads that both saw an empty
        # cache would otherwise both read the file, and the second would report
        # every key as "already in the environment" because the first had just
        # applied them. Streamlit runs each session in its own thread, so this
        # is a race that actually fires.
        with _LOCK:
            if _CACHED is not None:
                return _CACHED
            result = _attempt()
            _CACHED = result
            _LOADED_FROM = result.path
            return result

    result = _attempt()
    with _LOCK:
        if path is None and _CACHED is None:
            # A reload/override before any cached load still records the source.
            _LOADED_FROM = result.path
    return result


def loaded_from() -> Path | None:
    """The .env whose values are live in this process, if any."""
    return _LOADED_FROM


# ---------------------------------------------------------------------------
# Diagnostics
# ---------------------------------------------------------------------------

#: Whole-value template markers. Deliberately exact (or a "FILL IN ..."
#: prefix): matching on prefixes like "your"/"tbd"/"xxx" flags real passwords.
_TEMPLATE_EXACT = frozenset({"fill in", "changeme", "change me", "todo", "tbd",
                             "xxx", "your key", "your-key", "..."})


def is_placeholder(value: str) -> bool:
    """True if a value is obviously still the template text, not a real one."""
    v = value.strip()
    if not v:
        return False
    if v.startswith("<") and v.endswith(">"):
        return True
    low = v.lower()
    return low in _TEMPLATE_EXACT or low.startswith("fill in ")


def _mask(key: str, value: str) -> str:
    """Render a value for a diagnostic that may be pasted into a chat.

    Only names on the SAFE_TO_PRINT allow-list appear verbatim. DB_HOST gets a
    special case because "am I pointed at my laptop or at the shared server?"
    is the single most useful thing the self-check can tell you, and answering
    it does not require printing the hostname.
    """
    if not value:
        return "(empty)"
    upper = key.upper()
    if upper in SAFE_TO_PRINT:
        return value
    if upper == "DB_HOST":
        return ("localhost (this machine)" if value.strip().lower() in _LOOPBACK
                else f"a remote server ({len(value)} chars) — not this machine")
    if upper.endswith("_DIR") or upper.endswith("_PATH"):
        try:
            return f".../{Path(value).name}"
        except Exception:
            return f"set ({len(value)} chars)"
    return f"set ({len(value)} chars)"


def missing(names: Iterable[str]) -> list[str]:
    return [n for n in names if not os.environ.get(n)]


def report() -> str:
    """Human-readable config check. Safe to paste into a chat — no secrets."""
    result = load_env_file(reload=True)
    lines = ["AIM agent — environment self-check", "=" * 42]

    if result.path:
        lines.append(f".env file:      {result.path}")
        lines.append(f"keys in file:   {', '.join(sorted(set(result.applied) | set(result.skipped))) or '(none)'}")
        if result.skipped:
            lines.append(f"overridden by the environment: {', '.join(result.skipped)}")
    else:
        lines.append(".env file:      NOT FOUND")

    lines.append("")
    lines.append("Database:")
    unfilled: list[str] = []
    if os.environ.get("DATABASE_URL"):
        lines.append("   DATABASE_URL   set (overrides the DB_* variables)")
        db_missing: list[str] = []
    else:
        db_missing = missing(REQUIRED_DB)
        for name in REQUIRED_DB + ("DB_PORT", "DB_SSLMODE"):
            value = os.environ.get(name, "")
            if is_placeholder(value):
                lines.append(f"!! {name:<14} still template text — fill it in")
                unfilled.append(name)
            else:
                flag = "  " if value else "!!"
                lines.append(f"{flag} {name:<14} {_mask(name, value)}")

    lines.append("")
    lines.append("Agent:")
    for name in RECOMMENDED + ("AGENT_WORK_DIR", "AGENT_AUTOSTART"):
        value = os.environ.get(name, "")
        if is_placeholder(value):
            lines.append(f"!! {name:<22} still template text — fill it in")
            unfilled.append(name)
        else:
            lines.append(f"   {name:<22} {_mask(name, value)}")

    if result.warnings:
        lines.append("")
        lines.append("Warnings:")
        lines.extend(f"  - {w}" for w in result.warnings)

    lines.append("")
    if db_missing:
        lines.append("RESULT: not ready — missing " + ", ".join(db_missing))
    elif unfilled:
        lines.append("RESULT: not ready — still on template text: "
                     + ", ".join(sorted(set(unfilled)))
                     + "\n        Edit those lines in the .env, then re-run this check.")
    elif not os.environ.get("GEMINI_API_KEY") and not os.environ.get("GOOGLE_API_KEY"):
        lines.append("RESULT: database configured; extraction disabled "
                     "(no GEMINI_API_KEY) — crawling still works.")
    else:
        lines.append("RESULT: configuration looks complete.")
    return "\n".join(lines)


if __name__ == "__main__":
    print(report())
    sys.exit(0)
