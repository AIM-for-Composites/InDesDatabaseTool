"""Regression suite for envfile.py — one test per defect found in review.

Every check here failed at some point during the review pass that produced
envfile.py; they exist so those specific mistakes cannot come back. The most
important are C1 (report() must never print a value from the .env, because
users are told the output is safe to paste into a chat) and C2 (a variable
already present in the environment is never overwritten, which is what keeps
Hugging Face Space secrets authoritative).

Run:  python test_envfile.py        (no database or network needed)
"""
import os
import subprocess
import sys
import tempfile
import threading
from pathlib import Path

REPO = str(Path(__file__).resolve().parent)
sys.path.insert(0, REPO)

FAILS = []
PASSES = []


def check(name, cond, detail=""):
    (PASSES if cond else FAILS).append(name)
    print(f"{'PASS' if cond else 'FAIL'}  {name}" + (f"\n        {detail}" if not cond and detail else ""))


def fresh(env_text=None, environ=None, argv=("envfile.py",), cwd=None):
    """Run a snippet in a clean subprocess with a given .env, return stdout."""
    d = tempfile.mkdtemp()
    if env_text is not None:
        Path(d, ".env").write_bytes(env_text if isinstance(env_text, bytes)
                                    else env_text.encode())
    return d


def run_py(code, env=None, cwd=None):
    e = dict(os.environ)
    for k in ("DB_HOST", "DB_PORT", "DB_NAME", "DB_USER", "DB_PASSWORD", "DB_SSLMODE",
              "GEMINI_API_KEY", "GOOGLE_API_KEY", "AGENT_ADMIN_PASSWORD",
              "DATABASE_URL", "AGENT_ENV_FILE", "AGENT_WORK_DIR"):
        e.pop(k, None)
    e.update(env or {})
    r = subprocess.run([sys.executable, "-c", code], capture_output=True, text=True,
                       env=e, cwd=cwd or REPO)
    return r.stdout + r.stderr


BOOT = f"import sys; sys.path.insert(0, {REPO!r}); import envfile\n"

# --- CRITICAL 1: no value bytes anywhere in report() -------------------------
SECRETS = {
    "PW": "Tr0ub4dor&3-prod-secret",
    "HOST": "aim-prod.cluster-cxyz123.eu-west-1.rds.amazonaws.com",
    "USER": "aim_service_rw",
    "DBN": "aim_agent_prod",
    "KEY": "AIzaSyFAKEfakeFAKEfakeFAKEfakeFAKEfake123",
    "WORK": "/Users/jane.doe/clients/acme-confidential/agent_work",
}
d = fresh(f"""DB_HOST={SECRETS['HOST']}
DB_PORT=5432
DB_NAME={SECRETS['DBN']}
DB_USER={SECRETS['USER']}
DB_PASSWORD={SECRETS['PW']}
DB_SSLMODE: {SECRETS['PW']}
AGENT_ADMIN_PASSWORD="hunter2"{SECRETS['PW']}
GEMINI_API_KEY={SECRETS['KEY']}
AGENT_WORK_DIR={SECRETS['WORK']}
postgresql://{SECRETS['USER']}:{SECRETS['PW']}@{SECRETS['HOST']}:5432/db
""")
out = run_py(BOOT + "print(envfile.report())", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
leaked = [n for n, v in SECRETS.items() if v in out]
check("C1 report() prints no secret value (incl. inside warnings)", not leaked,
      f"leaked: {leaked}\n--- output ---\n{out}")

# --- CRITICAL 2: present-but-empty env vars are not overwritten --------------
d = fresh("DB_SSLMODE=require\nGEMINI_API_KEY=key-from-file\n")
out = run_py(BOOT + """
import os
os.environ['DB_SSLMODE'] = ''
os.environ['GEMINI_API_KEY'] = ''
r = envfile.load_env_file()
print('applied', r.applied)
print('sslmode', repr(os.environ['DB_SSLMODE']))
""", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("C2 a deliberately-blank env var is not refilled from the file",
      "'DB_SSLMODE'" not in out.split("applied")[1].split("\n")[0] and "sslmode ''" in out, out)

# --- CRITICAL 3: never raises ------------------------------------------------
cases = {
    "NUL byte in a value": (b"DB_PASSWORD=ab\x00cd\n", {}),
    "truncated UTF-16": (b"\xff\xfe" + "DB_HOST=h\n".encode("utf-16-le") + b"A", {}),
    "AGENT_ENV_FILE with a bad ~user": (None, {"AGENT_ENV_FILE": "~nosuchuser42/.env"}),
}
for label, (content, extra) in cases.items():
    d = fresh(content) if content is not None else tempfile.mkdtemp()
    env = dict(extra)
    if content is not None:
        env["AGENT_ENV_FILE"] = str(Path(d, ".env"))
    out = run_py(BOOT + "r = envfile.load_env_file(); print('OK', len(r.warnings))", env=env)
    check(f"C3 never raises — {label}", "OK" in out and "Traceback" not in out, out)

out = run_py(BOOT + """
import os, tempfile, shutil
d = tempfile.mkdtemp(); os.chdir(d); shutil.rmtree(d)
r = envfile.load_env_file()
print('OK', r.path)
""")
check("C3 never raises — cwd deleted underneath the process",
      "OK" in out and "Traceback" not in out, out)

# --- CRITICAL 4: Windows paths in double quotes survive ----------------------
d = fresh('AGENT_WORK_DIR="C:\\temp\\notes"\nP2="C:\\Users\\tom\\new"\nQ="say \\"hi\\""\nB="a\\\\b"\n')
out = run_py(BOOT + """
r = envfile.load_env_file()
import os
for k in ('AGENT_WORK_DIR','P2','Q','B'): print(k, repr(os.environ.get(k)))
""", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("C4 double-quoted Windows paths keep their backslashes",
      repr("C:\\temp\\notes") in out and repr("C:\\Users\\tom\\new") in out, out)
check("C4 \\\" and \\\\ still unescape",
      repr('say "hi"') in out and repr("a\\b") in out, out)

# --- MAJOR 5: host/user/dbname are masked ------------------------------------
out_lines = [l for l in out.splitlines()]
d = fresh(f"DB_HOST={SECRETS['HOST']}\nDB_NAME={SECRETS['DBN']}\nDB_USER={SECRETS['USER']}\n"
          f"DB_PASSWORD=x\nDB_PORT=5432\nDB_SSLMODE=require\n")
out = run_py(BOOT + "print(envfile.report())", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("M5 DB_HOST/DB_NAME/DB_USER are not echoed verbatim",
      SECRETS['HOST'] not in out and SECRETS['DBN'] not in out and SECRETS['USER'] not in out, out)
check("M5 DB_PORT/DB_SSLMODE (harmless) still shown", "5432" in out and "require" in out, out)
check("M5 remote vs local is still distinguishable", "not this machine" in out, out)

d2 = fresh("DB_HOST=localhost\nDB_NAME=a\nDB_USER=b\nDB_PASSWORD=c\n")
out2 = run_py(BOOT + "print(envfile.report())", env={"AGENT_ENV_FILE": str(Path(d2, ".env"))})
check("M5 a local host is reported as local", "this machine" in out2 and "not this machine" not in out2, out2)

# --- MAJOR 6: report() does not poison the cache -----------------------------
d = fresh("DB_HOST=h\nDB_NAME=n\nDB_USER=u\nDB_PASSWORD=p\nGEMINI_API_KEY=k\n")
out = run_py(BOOT + """
r1 = envfile.load_env_file()
envfile.report()
r2 = envfile.load_env_file()
print('first', len(r1.applied), 'after_report', len(r2.applied))
""", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("M6 load_env_file() after report() still reports the keys it applied",
      "first 5 after_report 5" in out, out)

# --- MAJOR 7: override=True is honoured after a cached load ------------------
out = run_py(BOOT + """
import os
envfile.load_env_file()
os.environ['DB_HOST'] = 'set-by-environment'
r = envfile.load_env_file(override=True)
print('host', os.environ['DB_HOST'], 'applied', 'DB_HOST' in r.applied)
""", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("M7 override=True re-reads instead of returning the cache",
      "host h" in out and "applied True" in out, out)

# --- MAJOR 8: loaded_from() names the file whose values are live ------------
a = fresh("DB_HOST=from_a\n"); b = fresh("DB_HOST=from_b\n")
out = run_py(BOOT + f"""
import os
envfile.load_env_file()
envfile.load_env_file(path={str(Path(b, '.env'))!r})
print('live', os.environ['DB_HOST'], 'loaded_from', envfile.loaded_from())
""", env={"AGENT_ENV_FILE": str(Path(a, ".env"))})
check("M8 loaded_from() matches the values actually live",
      "live from_a" in out and str(Path(a, ".env")) in out, out)

# --- MAJOR 9: a .env from outside the project warns --------------------------
# Hermetic: envfile.py is copied into the fake project so that the module
# directory (which it searches first) is the fake project, not this repo.
import shutil
outer = tempfile.mkdtemp()
Path(outer, ".env").write_text("DB_HOST=someone_elses\n")
proj = Path(outer, "proj"); (proj / "sub").mkdir(parents=True)
shutil.copy(Path(REPO, "envfile.py"), proj / "envfile.py")
out = run_py("""
import sys; sys.path.insert(0, %r); import envfile
r = envfile.load_env_file()
print('path', r.path)
print('warned', any('outside the project folder' in w for w in r.warnings))
""" % str(proj), cwd=str(proj / "sub"))
check("M9 a .env from a parent directory is flagged, not applied silently",
      ("path None" in out) or ("warned True" in out), out)

# --- MAJOR 10: non-UTF-8 file is reported ------------------------------------
d = fresh("DB_PASSWORD=pésswßrd\n".encode("latin-1"))
out = run_py(BOOT + """
r = envfile.load_env_file()
print('warned', any('not valid UTF-8' in w for w in r.warnings))
""", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("M10 a non-UTF-8 .env warns instead of silently corrupting", "warned True" in out, out)

# --- MINOR: UTF-16 with no BOM -----------------------------------------------
d = fresh("DB_HOST=localhost\n".encode("utf-16-le"))
out = run_py(BOOT + """
import os
r = envfile.load_env_file()
print('host', repr(os.environ.get('DB_HOST')), 'warned', any('UTF-16' in w for w in r.warnings))
""", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("m UTF-16 without a BOM is detected and decoded",
      "host 'localhost'" in out and "warned True" in out, out)

# --- MINOR: .env is a directory ----------------------------------------------
d = tempfile.mkdtemp(); Path(d, ".env").mkdir()
out = run_py(BOOT + "r = envfile.load_env_file(); print([w for w in r.warnings])",
             env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("m a .env that is a directory says so", "is a directory" in out, out)

# --- MINOR: duplicate keys ---------------------------------------------------
d = fresh("DB_PASSWORD=first\nDB_PASSWORD=second\n")
out = run_py(BOOT + "r = envfile.load_env_file(); print([w for w in r.warnings])",
             env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("m a redefined key warns (without printing either value)",
      "redefined" in out and "first" not in out and "second" not in out, out)

# --- MINOR: unclosed quote ---------------------------------------------------
d = fresh('PEM="-----BEGIN-----\n')
out = run_py(BOOT + """
import os
r = envfile.load_env_file()
print('val', repr(os.environ.get('PEM')), 'warned', any('never closed' in w for w in r.warnings))
""", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("m an unclosed quote drops the quote and warns",
      "val '-----BEGIN-----'" in out and "warned True" in out, out)

# --- MINOR: is_placeholder false positives -----------------------------------
out = run_py(BOOT + """
real = ['Todo1234!', 'XXXhunter', 'tbd-cluster-01', 'xxxxxxxx-real-password',
        'your-org-prod-db.rds.amazonaws.com', 'Yourkey123']
tmpl = ['<your key>', 'FILL IN', 'FILL IN — the password you set', 'changeme', 'TODO']
print('false_positives', [v for v in real if envfile.is_placeholder(v)])
print('missed', [v for v in tmpl if not envfile.is_placeholder(v)])
""")
check("m is_placeholder has no false positives on real secrets",
      "false_positives []" in out, out)
check("m is_placeholder still catches template text", "missed []" in out, out)

# --- MINOR: '#' truncation is announced --------------------------------------
d = fresh("DB_PASSWORD=Pa55 #word!x\n")
out = run_py(BOOT + "r = envfile.load_env_file(); print([w for w in r.warnings])",
             env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("m truncation at ' #' is announced and quotes no value",
      "comment" in out and "Pa55" not in out, out)

# --- MINOR: bad key names ----------------------------------------------------
d = fresh("1KEY=x\nCLÉ=y\ndb_password=z\nGOOD_KEY=ok\n")
out = run_py(BOOT + """
import os
r = envfile.load_env_file()
print('good', os.environ.get('GOOD_KEY'))
print('bad_rejected', all(k not in os.environ for k in ('1KEY','CLÉ')))
print('lower_warned', any('lower-case' in w for w in r.warnings))
""", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("m invalid key names are rejected, valid ones still load",
      "good ok" in out and "bad_rejected True" in out, out)
check("m a lower-case key warns that it will be ignored", "lower_warned True" in out, out)

# --- MINOR: thread race ------------------------------------------------------
d = fresh("RACE_KEY=v\nDB_HOST=h\n")
out = run_py(BOOT + """
import threading
res = []
def go(): res.append(envfile.load_env_file())
ts = [threading.Thread(target=go) for _ in range(16)]
[t.start() for t in ts]; [t.join() for t in ts]
applied = {r.applied for r in res}
print('distinct_results', len(applied))
""", env={"AGENT_ENV_FILE": str(Path(d, ".env"))})
check("m concurrent loads all see the same result", "distinct_results 1" in out, out)

print("\n" + "=" * 60)
print(f"{len(PASSES)} passed, {len(FAILS)} failed")
if FAILS:
    print("FAILED:", ", ".join(FAILS))
sys.exit(1 if FAILS else 0)
