"""Background autonomy: an APScheduler that fires agent cycles on an interval.

Runs inside the Streamlit server process (Docker Space), independent of
viewers. The schedule is (re)derived from durable config in agent_state, so a
container restart resumes exactly where the team left it.
"""
from __future__ import annotations

import logging
import threading

from apscheduler.schedulers.background import BackgroundScheduler

from agent import agdb, orchestrator

log = logging.getLogger("agent.scheduler")

_lock = threading.Lock()
_scheduler: BackgroundScheduler | None = None
JOB_ID = "agent-cycle"


def _cycle_job() -> None:
    try:
        orchestrator.run_cycle(trigger="schedule")
    except Exception:
        log.exception("scheduled cycle failed")


def get_scheduler() -> BackgroundScheduler:
    global _scheduler
    with _lock:
        if _scheduler is None:
            _scheduler = BackgroundScheduler(daemon=True,
                                             timezone="UTC",
                                             job_defaults={"coalesce": True,
                                                           "max_instances": 1,
                                                           "misfire_grace_time": 3600})
            _scheduler.start()
        return _scheduler


def sync_from_config() -> dict:
    """Make the live schedule match durable config. Returns the config used."""
    conn = agdb.connect()
    try:
        agdb.ensure_agent_schema(conn)
        cfg = agdb.get_config(conn)
    finally:
        conn.close()

    sched = get_scheduler()
    job = sched.get_job(JOB_ID)
    if cfg.get("autonomy"):
        hours = max(0.25, float(cfg.get("interval_hours", 6)))
        if job is None:
            sched.add_job(_cycle_job, "interval", hours=hours, id=JOB_ID)
            log.info("autonomy ON — cycle every %.2f h", hours)
        else:
            # reschedule only if the interval changed
            current = getattr(job.trigger, "interval", None)
            if current is None or abs(current.total_seconds() - hours * 3600) > 1:
                sched.reschedule_job(JOB_ID, trigger="interval", hours=hours)
                log.info("autonomy rescheduled — every %.2f h", hours)
    elif job is not None:
        sched.remove_job(JOB_ID)
        log.info("autonomy OFF")
    return cfg


def run_now() -> None:
    """Fire one cycle immediately in the background (non-blocking)."""
    sched = get_scheduler()
    sched.add_job(orchestrator.run_cycle, kwargs={"trigger": "manual"},
                  id="agent-cycle-manual", replace_existing=True)


def next_run_time():
    sched = get_scheduler()
    job = sched.get_job(JOB_ID)
    return job.next_run_time if job else None
