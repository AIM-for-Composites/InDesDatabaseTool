"""AIM Composites autonomous ingestion agent package."""
