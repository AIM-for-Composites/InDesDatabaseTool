"""The autonomous ingestion agent.

One *cycle* is a run of the agent graph:

    plan ─▶ discover ─▶ dedupe ─▶ download ─▶ ingest ─▶ report

  plan      pick the next N queries from the frontier (LRU rotation), load config
  discover  OpenAlex / arXiv (/ Semantic Scholar) search per query — DOI-native
  dedupe    drop candidates whose DOI, URL, or content hash was already seen
  download  polite, validated PDF download (pdf_crawler.download_pdf)
  ingest    extraction.py → grounding → unit norm → status → Postgres
            (batch_ingest.process_pdf with the pg_mirror backend — the same
            tables the MaterialsDatabase Space reads)
  report    persist run metrics + crawler seen-sets, optionally expand queries

The graph is a LangGraph ``StateGraph`` when langgraph is installed (it is in
requirements.txt) and transparently degrades to a plain sequential runner when
not — the node functions are identical either way.

Everything durable lives in Postgres (agent_* tables); the PDF work dir is
ephemeral by design.
"""
from __future__ import annotations

import logging
import time
import traceback
from pathlib import Path
from typing import Any, Callable, Optional, TypedDict

import batch_ingest
import pdf_crawler
import pg_mirror
from agent import agdb, config as C

log = logging.getLogger("agent")


class AgentState(TypedDict, total=False):
    trigger: str
    run_id: int
    cfg: dict
    queries: list          # [(id, query)]
    candidates: list       # pdf_crawler.Candidate
    fresh: list            # candidates surviving dedupe
    downloads: list        # download record dicts
    metrics: dict
    report: dict
    error: str


# ---------------------------------------------------------------------------
# Nodes (each takes and returns AgentState; DB via short-lived connections)
# ---------------------------------------------------------------------------


def node_plan(state: AgentState) -> AgentState:
    conn = agdb.connect()
    try:
        cfg = agdb.get_config(conn)
        queries = agdb.next_queries(conn, int(cfg["queries_per_cycle"]))
        agdb.log_event(conn, f"cycle start (trigger={state['trigger']}): "
                             f"{len(queries)} queries, cap {cfg['max_new_pdfs_per_cycle']} PDFs",
                       node="plan", run_id=state["run_id"])
        state["cfg"] = cfg
        state["queries"] = queries
        m = state.setdefault("metrics", {})
        m["queries_used"] = len(queries)
    finally:
        conn.close()
    return state


def node_discover(state: AgentState) -> AgentState:
    cfg = state["cfg"]
    per_query = int(cfg["max_per_query"])
    min_score = int(cfg.get("min_relevance_score", pdf_crawler.MIN_SCORE))
    candidates: list = []
    conn = agdb.connect()
    try:
        for _qid, query in state["queries"]:
            found_here = 0
            searchers: list[Callable] = []
            if cfg.get("use_openalex", True):
                searchers.append(pdf_crawler.search_openalex)
            if cfg.get("use_arxiv", True):
                searchers.append(pdf_crawler.search_arxiv)
            if cfg.get("use_semantic_scholar", False):
                searchers.append(pdf_crawler.search_semantic_scholar)
            for search in searchers:
                try:
                    for cand in search(query, per_query):
                        score = pdf_crawler.relevance_score(
                            f"{cand.title} {cand.abstract}")
                        if score < min_score:
                            continue
                        candidates.append(cand)
                        found_here += 1
                except Exception as exc:  # network / API failure → log, move on
                    agdb.log_event(conn, f"{search.__name__}({query!r}) failed: {exc}",
                                   level="warn", node="discover", run_id=state["run_id"])
        agdb.log_event(conn, f"{len(candidates)} relevant candidates discovered",
                       node="discover", run_id=state["run_id"])
    finally:
        conn.close()
    state["candidates"] = candidates
    state["metrics"]["candidates"] = len(candidates)
    return state


def node_dedupe(state: AgentState) -> AgentState:
    """DOI-first dedupe against the durable registry, before any download."""
    conn = agdb.connect()
    fresh, skipped = [], 0
    seen_this_cycle: set[str] = set()
    try:
        for cand in state["candidates"]:
            key = cand.doi or cand.pdf_url
            if key in seen_this_cycle:
                skipped += 1
                continue
            if cand.doi and agdb.seen_doi(conn, cand.doi):
                skipped += 1
                continue
            seen_this_cycle.add(key)
            fresh.append(cand)
        agdb.log_event(conn, f"dedupe: {skipped} already-seen skipped, {len(fresh)} fresh",
                       node="dedupe", run_id=state["run_id"])
    finally:
        conn.close()
    state["fresh"] = fresh
    state["metrics"]["skipped_doi"] = skipped
    return state


def node_download(state: AgentState) -> AgentState:
    cfg = state["cfg"]
    cap = min(int(cfg["max_new_pdfs_per_cycle"]), C.HARD_MAX_PDFS_PER_CYCLE)
    C.ensure_dirs()
    conn = agdb.connect()
    downloads: list[dict] = []
    try:
        crawler_state = pdf_crawler.CrawlerState(C.WORK_DIR / "state.json")
        agdb.load_crawler_state(conn, crawler_state)   # durable seen URL/hash sets
        for cand in state["fresh"]:
            if len(downloads) >= cap:
                break
            try:
                rec = pdf_crawler.download_pdf(cand, C.PDF_DIR, crawler_state)
            except Exception as exc:
                agdb.log_event(conn, f"download failed {cand.pdf_url}: {exc}",
                               level="warn", node="download", run_id=state["run_id"])
                continue
            if not rec:
                continue
            agdb.record_download(conn, rec)
            rec["_query"] = cand.query
            downloads.append(rec)
            agdb.log_event(conn, f"downloaded [{rec['source']}] {rec['filename']} "
                                 f"(doi={rec.get('doi') or '—'})",
                           node="download", run_id=state["run_id"])
        agdb.save_crawler_state(conn, crawler_state)
    finally:
        conn.close()
    state["downloads"] = downloads
    state["metrics"]["downloaded"] = len(downloads)
    return state


def node_ingest(state: AgentState) -> AgentState:
    m = state["metrics"]
    m.setdefault("pdfs_ingested", 0)
    m.setdefault("rows_inserted", 0)
    m.setdefault("rows_flagged", 0)
    m.setdefault("duplicates", 0)
    m.setdefault("errors", 0)
    results = []
    if not state["downloads"]:
        state["report"] = {"pdf_results": []}
        return state
    if not C.GEMINI_API_KEY:
        state["error"] = "GEMINI_API_KEY is not set — downloaded PDFs kept for next cycle"
        state["report"] = {"pdf_results": []}
        return state

    pg = pg_mirror.connect_from_env()
    meta_conn = agdb.connect()
    try:
        pg_mirror.check_schema(pg)   # refuse to write to an unmigrated schema
        query_rows: dict[str, int] = {}
        for rec in state["downloads"]:
            pdf_path = C.PDF_DIR / rec["filename"]
            try:
                result = batch_ingest.process_pdf(pdf_path, pg, C.GEMINI_API_KEY,
                                                  db=pg_mirror)
            except Exception as exc:
                m["errors"] += 1
                agdb.update_ingest_status(meta_conn, rec["filename"], f"error")
                agdb.log_event(meta_conn,
                               f"ingest error {rec['filename']}: {exc}",
                               level="error", node="ingest", run_id=state["run_id"])
                continue
            results.append(result)
            if result.error:
                agdb.update_ingest_status(meta_conn, rec["filename"], result.error)
                agdb.log_event(meta_conn, f"{rec['filename']}: {result.error}",
                               level="warn", node="ingest", run_id=state["run_id"])
                continue
            m["pdfs_ingested"] += 1
            m["rows_inserted"] += result.inserted
            m["rows_flagged"] += result.flagged
            m["duplicates"] += result.duplicates
            query_rows[rec.get("_query", "")] = (
                query_rows.get(rec.get("_query", ""), 0) + result.inserted)
            agdb.update_ingest_status(meta_conn, rec["filename"], "ingested",
                                      result.inserted, result.flagged)
            agdb.log_event(meta_conn,
                           f"{rec['filename']}: {result.materials} materials, "
                           f"{result.inserted} rows inserted ({result.flagged} flagged)",
                           node="ingest", run_id=state["run_id"])
            # PDFs are ephemeral once ingested — provenance stays in Postgres.
            pdf_path.unlink(missing_ok=True)

        # per-query yield bookkeeping (feeds LRU rotation + expansion decisions)
        for qid, query in state["queries"]:
            pdfs_found = sum(1 for r in state["downloads"] if r.get("_query") == query)
            agdb.mark_query_used(meta_conn, qid, pdfs_found, query_rows.get(query, 0))

        try:
            n_review = pg_mirror.export_review_queue(pg, C.REVIEW_CSV)
            m["review_rows"] = n_review
        except Exception:
            pass
    finally:
        pg.close()
        meta_conn.close()

    state["report"] = {
        "pdf_results": [
            {"pdf": r.pdf, "error": r.error, "materials": r.materials,
             "inserted": r.inserted, "flagged": r.flagged,
             "duplicates": r.duplicates, "elapsed_s": round(r.elapsed_s, 1)}
            for r in results
        ],
        "summary": batch_ingest.summarize(results) if results else {},
    }
    return state


def node_report(state: AgentState) -> AgentState:
    conn = agdb.connect()
    try:
        cfg = state.get("cfg", {})
        # Optional: when a cycle comes up dry, ask Gemini for fresh query intents.
        if (cfg.get("expand_queries") and C.GEMINI_API_KEY
                and state["metrics"].get("downloaded", 0) == 0
                and state.get("queries")):
            try:
                import generate_queries as gq
                new = gq.dedup_against_existing(
                    gq.generate_queries(5, "", C.GEMINI_API_KEY, ""))
                if new:
                    added = agdb.seed_queries(conn, new, origin="gemini")
                    agdb.log_event(conn, f"query expansion: +{added} new queries",
                                   node="report", run_id=state["run_id"])
            except Exception as exc:
                agdb.log_event(conn, f"query expansion failed: {exc}",
                               level="warn", node="report", run_id=state["run_id"])

        status = "error" if state.get("error") else "ok"
        if state.get("error"):
            agdb.log_event(conn, state["error"], level="error", node="report",
                           run_id=state["run_id"])
        agdb.finish_run(conn, state["run_id"], status,
                        state.get("metrics", {}), state.get("report", {}))
        m = state.get("metrics", {})
        agdb.log_event(conn,
                       f"cycle done: {m.get('downloaded', 0)} downloaded, "
                       f"{m.get('rows_inserted', 0)} rows inserted "
                       f"({m.get('rows_flagged', 0)} flagged) from "
                       f"{m.get('pdfs_ingested', 0)} PDFs",
                       node="report", run_id=state["run_id"])
    finally:
        conn.close()
    return state


NODES: list[tuple[str, Callable[[AgentState], AgentState]]] = [
    ("plan", node_plan),
    ("discover", node_discover),
    ("dedupe", node_dedupe),
    ("download", node_download),
    ("ingest", node_ingest),
    ("report", node_report),
]


# ---------------------------------------------------------------------------
# Graph assembly — LangGraph when available, sequential otherwise
# ---------------------------------------------------------------------------


def _build_langgraph():
    from langgraph.graph import StateGraph, END
    g = StateGraph(AgentState)
    for name, fn in NODES:
        g.add_node(name, fn)
    g.set_entry_point("plan")
    for (a, _), (b, _) in zip(NODES, NODES[1:]):
        g.add_edge(a, b)
    g.add_edge("report", END)
    return g.compile()


def _run_sequential(state: AgentState) -> AgentState:
    for _name, fn in NODES:
        state = fn(state)
    return state


def run_cycle(trigger: str = "schedule") -> dict:
    """Run one full agent cycle. Returns the final metrics dict.

    Single-flight: a durable lock in agent_state prevents overlapping cycles
    (including across container restarts; stale locks expire).
    """
    conn = agdb.connect()
    try:
        agdb.ensure_agent_schema(conn)
        if not agdb.acquire_cycle_lock(conn):
            log.info("cycle already running — skipping")
            return {"skipped": "already_running"}
        run_id = agdb.start_run(conn, trigger)
    finally:
        conn.close()

    state: AgentState = {"trigger": trigger, "run_id": run_id, "metrics": {}}
    try:
        try:
            app = _build_langgraph()
            final = app.invoke(state)
        except ImportError:
            final = _run_sequential(state)
        return dict(final.get("metrics", {}))
    except Exception:
        err = traceback.format_exc(limit=8)
        conn = agdb.connect()
        try:
            agdb.log_event(conn, f"cycle crashed:\n{err}", level="error",
                           node="cycle", run_id=run_id)
            agdb.finish_run(conn, run_id, "crashed", state.get("metrics", {}),
                            {"traceback": err})
        finally:
            conn.close()
        raise
    finally:
        conn = agdb.connect()
        try:
            agdb.release_cycle_lock(conn)
        finally:
            conn.close()


def bootstrap(seed_default_queries: bool = True) -> None:
    """One-time-ish setup at app boot: agent schema + default query frontier."""
    conn = agdb.connect()
    try:
        agdb.ensure_agent_schema(conn)
        if seed_default_queries:
            agdb.seed_queries(conn, list(pdf_crawler.DEFAULT_QUERIES), origin="builtin")
    finally:
        conn.close()
