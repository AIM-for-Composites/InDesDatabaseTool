"""Central configuration for the autonomous agent Space.

Everything is read from the environment (HF Space secrets/variables) with
safe defaults. Runtime-tunable knobs (interval, caps, autonomy on/off) live
in the `agent_state` Postgres table so they survive restarts and are editable
from the Run Control page — the values here are only the first-boot defaults.
"""
from __future__ import annotations

import os
from pathlib import Path


def _f(name: str, default: float) -> float:
    try:
        return float(os.environ.get(name, "") or default)
    except ValueError:
        return default


def _i(name: str, default: int) -> int:
    try:
        return int(os.environ.get(name, "") or default)
    except ValueError:
        return default


def _b(name: str, default: bool) -> bool:
    raw = (os.environ.get(name) or "").strip().lower()
    if not raw:
        return default
    return raw in ("1", "true", "yes", "on")


# --- credentials ------------------------------------------------------------
GEMINI_API_KEY = os.environ.get("GEMINI_API_KEY") or os.environ.get("GOOGLE_API_KEY") or ""
ADMIN_PASSWORD = os.environ.get("AGENT_ADMIN_PASSWORD", "")          # empty → controls locked
CONTACT_EMAIL = os.environ.get("CONTACT_EMAIL", "mathias.heider@gmail.com")

# --- working dirs (ephemeral on HF Spaces — durable state lives in Postgres) -
WORK_DIR = Path(os.environ.get("AGENT_WORK_DIR", "/tmp/agent_work"))
PDF_DIR = WORK_DIR / "pdfs"
REVIEW_CSV = WORK_DIR / "review_queue.csv"

# --- first-boot defaults for runtime-tunable knobs (agent_state overrides) --
DEFAULTS = {
    "autonomy": _b("AGENT_AUTOSTART", False),      # start crawling on boot?
    "interval_hours": _f("AGENT_INTERVAL_HOURS", 6.0),
    "max_new_pdfs_per_cycle": _i("AGENT_MAX_PDFS", 5),
    "max_per_query": _i("AGENT_MAX_PER_QUERY", 4),
    "queries_per_cycle": _i("AGENT_QUERIES_PER_CYCLE", 3),
    "use_arxiv": True,
    "use_openalex": True,
    "use_semantic_scholar": False,   # free tier 429s constantly; enable with S2_API_KEY
    "expand_queries": False,         # let Gemini propose new queries when yields drop
    "min_relevance_score": 4,        # pdf_crawler.MIN_SCORE
}

STATE_KEYS = list(DEFAULTS)

# Safety rails (not runtime-tunable).
HARD_MAX_PDFS_PER_CYCLE = _i("AGENT_HARD_MAX_PDFS", 25)
CYCLE_STALE_MINUTES = 90             # a 'running' flag older than this is considered crashed


def ensure_dirs() -> None:
    PDF_DIR.mkdir(parents=True, exist_ok=True)
