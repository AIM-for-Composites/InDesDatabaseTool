"""Review Queue — flagged (status != 'ok') rows across the material tables."""
import pandas as pd
import streamlit as st

from agent import agdb
from agent.ui_common import admin_gate, status_banner

st.title("🔍 Review Queue")
status_banner()
admin = admin_gate()

TABLES = ("Polymers", "Fibers", "Composites_materials")
COLS = ("id, source_pdf, page, status, flag_reason, material_name, material_key, "
        "section, property_name, value_raw, unit, unit_canonical, value_si, "
        "test_condition, source_quote")

frames = []
conn = agdb.connect()
try:
    for t in TABLES:
        try:
            df = agdb.fetch_df(
                conn,
                f'SELECT \'{t}\' AS table_name, {COLS} FROM "{t}" '
                f"WHERE COALESCE(status, 'ok') <> 'ok' "
                f"ORDER BY extracted_at DESC NULLS LAST LIMIT 500")
            frames.append(df)
        except Exception:
            conn.rollback()
finally:
    conn.close()

queue = pd.concat(frames, ignore_index=True) if frames else pd.DataFrame()
if queue.empty:
    st.success("Review queue is empty — every published row is status 'ok'. 🎉")
    st.stop()

f1, f2 = st.columns(2)
with f1:
    statuses = sorted(queue["status"].dropna().unique())
    pick = st.multiselect("Status", statuses, default=statuses)
with f2:
    pdfs = ["(all)"] + sorted(queue["source_pdf"].dropna().unique())
    pdf_pick = st.selectbox("Source PDF", pdfs)

view = queue[queue["status"].isin(pick)]
if pdf_pick != "(all)":
    view = view[view["source_pdf"] == pdf_pick]

st.metric("Flagged rows", len(view))
st.dataframe(view.drop(columns=["id"]), hide_index=True,
             width='stretch', height=480)

st.download_button("⬇️ Download review_queue.csv",
                   view.to_csv(index=False).encode(),
                   "review_queue.csv", "text/csv")

# --- promote (admin) --------------------------------------------------------
st.subheader("Promote corrected rows")
st.caption("After a human verifies a flagged value is correct, promote it to "
           "status 'ok' so it appears in search results. Same semantics as "
           "`batch_ingest.py --promote`.")
if admin:
    sel_pdf = st.selectbox("Promote all flagged rows from PDF",
                           ["(choose)"] + sorted(view["source_pdf"].dropna().unique()))
    sure = st.checkbox("I reviewed these values against the source PDF")
    if st.button("✅ Promote", disabled=(sel_pdf == "(choose)" or not sure)):
        conn = agdb.connect()
        try:
            n = 0
            with conn.cursor() as cur:
                for t in TABLES:
                    cur.execute(
                        f'UPDATE "{t}" SET status = \'ok\', flag_reason = \'promoted\' '
                        f"WHERE source_pdf = %s AND COALESCE(status, 'ok') <> 'ok'",
                        (sel_pdf,))
                    n += cur.rowcount
            conn.commit()
            agdb.log_event(conn, f"promoted {n} rows from {sel_pdf}", node="review")
        finally:
            conn.close()
        st.success(f"Promoted {n} rows.")
        st.rerun()
else:
    st.info("Unlock admin in the sidebar to promote rows.")
