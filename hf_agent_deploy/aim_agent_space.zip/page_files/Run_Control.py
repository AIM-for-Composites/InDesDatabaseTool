"""Run Control — autonomy switch, caps, query frontier. Admin-gated."""
import pandas as pd
import streamlit as st

from agent import agdb, scheduler
from agent.ui_common import admin_gate, status_banner, df_or_empty

st.title("🎛️ Run Control")
status_banner()
admin = admin_gate()

conn = agdb.connect()
try:
    cfg = agdb.get_config(conn)
    lock = agdb.get_state(conn, "cycle_lock")
finally:
    conn.close()

# --- autonomy ---------------------------------------------------------------
st.subheader("Autonomy")
col1, col2, col3 = st.columns([1, 1, 2])
with col1:
    autonomy = st.toggle("Autonomous crawling", value=bool(cfg.get("autonomy")),
                         disabled=not admin)
with col2:
    interval = st.number_input("Interval (hours)", min_value=0.5, max_value=168.0,
                               value=float(cfg.get("interval_hours", 6)),
                               step=0.5, disabled=not admin)
with col3:
    st.caption("While ON, the agent runs a full discover→dedupe(DOI)→download→"
               "extract→publish cycle at this interval, viewers or not. "
               "Restarts resume automatically.")

st.subheader("Per-cycle budget")
b1, b2, b3 = st.columns(3)
with b1:
    max_pdfs = st.number_input("Max new PDFs per cycle", 1, 25,
                               int(cfg.get("max_new_pdfs_per_cycle", 5)),
                               disabled=not admin)
with b2:
    per_query = st.number_input("Max results per query/source", 1, 15,
                                int(cfg.get("max_per_query", 4)),
                                disabled=not admin)
with b3:
    n_queries = st.number_input("Queries per cycle", 1, 10,
                                int(cfg.get("queries_per_cycle", 3)),
                                disabled=not admin)

st.subheader("Sources & behavior")
s1, s2, s3, s4 = st.columns(4)
with s1:
    use_oa = st.checkbox("OpenAlex + Unpaywall", value=bool(cfg.get("use_openalex", True)),
                         disabled=not admin)
with s2:
    use_ax = st.checkbox("arXiv", value=bool(cfg.get("use_arxiv", True)),
                         disabled=not admin)
with s3:
    use_s2 = st.checkbox("Semantic Scholar", value=bool(cfg.get("use_semantic_scholar", False)),
                         disabled=not admin,
                         help="Free tier rate-limits hard; set an S2_API_KEY secret first.")
with s4:
    expand = st.checkbox("Gemini query expansion", value=bool(cfg.get("expand_queries", False)),
                         disabled=not admin,
                         help="When a cycle finds nothing new, ask Gemini for fresh search intents.")

if admin and st.button("💾 Save settings", type="primary"):
    conn = agdb.connect()
    try:
        agdb.set_config(conn, {
            "autonomy": autonomy, "interval_hours": float(interval),
            "max_new_pdfs_per_cycle": int(max_pdfs),
            "max_per_query": int(per_query), "queries_per_cycle": int(n_queries),
            "use_openalex": use_oa, "use_arxiv": use_ax,
            "use_semantic_scholar": use_s2, "expand_queries": expand,
        })
    finally:
        conn.close()
    scheduler.sync_from_config()
    st.success("Saved — schedule updated.")
    st.rerun()

# --- manual cycle -----------------------------------------------------------
st.subheader("Manual run")
if lock:
    st.info("A cycle is running right now — watch Runs & Logs.")
run_col, _sp = st.columns([1, 3])
with run_col:
    if st.button("▶️ Run one cycle now", disabled=not admin or bool(lock)):
        scheduler.run_now()
        st.success("Cycle started in the background — follow it in Runs & Logs.")

# --- query frontier ---------------------------------------------------------
st.subheader("Query frontier")
qdf = df_or_empty(
    "SELECT id, enabled, query, origin, times_used, pdfs_found, rows_yielded, "
    "last_used_at FROM agent_queries ORDER BY enabled DESC, id")
if qdf.empty:
    st.caption("No queries yet — they are seeded on first boot.")
else:
    edited = st.data_editor(
        qdf, hide_index=True, width='stretch',
        disabled=[] if admin else list(qdf.columns),
        column_config={
            "enabled": st.column_config.CheckboxColumn("On"),
            "last_used_at": st.column_config.DatetimeColumn(
                "Last used", format="MMM D, HH:mm"),
        },
        key="query_editor")
    if admin and st.button("💾 Save query changes"):
        conn = agdb.connect()
        try:
            with conn.cursor() as cur:
                for _, row in edited.iterrows():
                    cur.execute(
                        "UPDATE agent_queries SET enabled = %s, query = %s WHERE id = %s",
                        (bool(row["enabled"]), str(row["query"]), int(row["id"])))
            conn.commit()
        finally:
            conn.close()
        st.success("Queries updated.")
        st.rerun()

new_q = st.text_input("Add a query", placeholder="e.g. LCP glass fiber dielectric properties",
                      disabled=not admin)
if admin and st.button("➕ Add query") and new_q.strip():
    conn = agdb.connect()
    try:
        agdb.seed_queries(conn, [new_q.strip()], origin="manual")
    finally:
        conn.close()
    st.rerun()
