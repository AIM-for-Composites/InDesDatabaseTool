"""Runs & Logs — full agent history: cycles, per-PDF results, event stream."""
import json

import pandas as pd
import streamlit as st

from agent.ui_common import status_banner, df_or_empty

st.title("📜 Runs & Logs")
status_banner()

runs = df_or_empty(
    "SELECT id, started_at, finished_at, trigger, status, queries_used, "
    "candidates, skipped_doi, downloaded, pdfs_ingested, rows_inserted, "
    "rows_flagged, duplicates, errors, report "
    "FROM agent_runs ORDER BY id DESC LIMIT 50")

st.subheader("Cycle history")
if runs.empty:
    st.caption("No cycles recorded yet.")
else:
    st.dataframe(
        runs.drop(columns=["report"]),
        column_config={
            "started_at": st.column_config.DatetimeColumn("Started", format="MMM D, HH:mm:ss"),
            "finished_at": st.column_config.DatetimeColumn("Finished", format="HH:mm:ss"),
        },
        hide_index=True, width='stretch', height=300)

    pick = st.selectbox("Inspect run", runs["id"])
    row = runs[runs["id"] == pick].iloc[0]
    try:
        report = json.loads(row["report"] or "{}")
    except (TypeError, ValueError):
        report = {}
    pdf_results = report.get("pdf_results", [])
    if pdf_results:
        st.dataframe(pd.DataFrame(pdf_results), hide_index=True,
                     width='stretch')
    if report.get("summary"):
        with st.expander("Run summary JSON"):
            st.json(report["summary"])

st.subheader("Event stream")
level = st.selectbox("Level", ["all", "info", "warn", "error"])
where = "" if level == "all" else f"WHERE level = '{level}'"
events = df_or_empty(
    f"SELECT ts, run_id, level, node, message FROM agent_events {where} "
    f"ORDER BY id DESC LIMIT 300")
if events.empty:
    st.caption("No events yet.")
else:
    st.dataframe(
        events,
        column_config={"ts": st.column_config.DatetimeColumn(
            "Time", format="MMM D, HH:mm:ss")},
        hide_index=True, width='stretch', height=480)
