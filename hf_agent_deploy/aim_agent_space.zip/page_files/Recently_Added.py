"""Recently Added — what the agent ingested lately, with DOI provenance."""
import pandas as pd
import streamlit as st

from agent.ui_common import status_banner, df_or_empty

st.title("🆕 Recently Added")
status_banner()

# Per-PDF roll-up across the three material tables, newest first.
UNION = (
    "SELECT source_pdf, material_abbreviation, material_class, status, extracted_at "
    "FROM \"Polymers\" WHERE source_pdf IS NOT NULL "
    "UNION ALL "
    "SELECT source_pdf, material_abbreviation, material_class, status, extracted_at "
    "FROM \"Fibers\" WHERE source_pdf IS NOT NULL "
    "UNION ALL "
    "SELECT source_pdf, material_abbreviation, material_class, status, extracted_at "
    "FROM \"Composites_materials\" WHERE source_pdf IS NOT NULL"
)
df = df_or_empty(
    f"SELECT source_pdf, "
    f"       max(extracted_at) AS added, "
    f"       count(*) AS properties, "
    f"       count(*) FILTER (WHERE COALESCE(status,'ok') = 'ok') AS verified, "
    f"       string_agg(DISTINCT material_abbreviation, ', ') AS materials, "
    f"       string_agg(DISTINCT material_class, ', ') AS classes "
    f"FROM ({UNION}) t GROUP BY source_pdf ORDER BY added DESC NULLS LAST LIMIT 100")

if df.empty:
    st.info("Nothing ingested yet — once the agent (or a `batch_ingest.py --pg` "
            "run) publishes rows, they appear here newest-first.")
    st.stop()

# Join DOI + title provenance from the agent registry when available.
prov = df_or_empty("SELECT filename, doi, title, source, url FROM agent_doi_seen")
if not prov.empty:
    df = df.merge(prov, how="left", left_on="source_pdf", right_on="filename")
    df["doi"] = df["doi"].fillna("").map(lambda d: f"https://doi.org/{d}" if d else "")
else:
    df["doi"], df["title"], df["source"] = "", "", ""

df["added"] = df["added"].astype(str).str.slice(0, 16).str.replace("T", " ")
fresh_cutoff = (pd.Timestamp.now(tz='UTC') - pd.Timedelta(days=14)).strftime("%Y-%m-%d")
df["fresh"] = df["added"] >= fresh_cutoff

c1, c2, c3 = st.columns(3)
c1.metric("Source documents", len(df))
c2.metric("Verified property rows", int(df["verified"].sum()))
c3.metric("New in last 14 days", int(df["fresh"].sum()))

show = df[["added", "source_pdf", "title", "materials", "classes",
           "properties", "verified", "doi", "source"]].copy()
show.insert(0, "", df["fresh"].map(lambda f: "🆕" if f else ""))
st.dataframe(
    show,
    column_config={
        "added": "Added (UTC)",
        "source_pdf": "PDF",
        "title": "Paper / datasheet title",
        "properties": st.column_config.NumberColumn("Props"),
        "verified": st.column_config.NumberColumn("Verified"),
        "doi": st.column_config.LinkColumn("DOI"),
    },
    hide_index=True, width='stretch', height=560)

st.caption("Verified = rows with status 'ok' (grounded in the PDF, unit-sane, "
           "plausible). Flagged rows are quarantined in the Review Queue.")
