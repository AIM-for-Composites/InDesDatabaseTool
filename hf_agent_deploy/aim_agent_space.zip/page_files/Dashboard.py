"""Dashboard — live view of the autonomous agent and the shared database."""
import pandas as pd
import streamlit as st

from agent import agdb, scheduler
from agent.ui_common import status_banner, df_or_empty

st.title("🤖 AIM Autonomous Ingestion Agent")
status_banner()

# --- agent status row -------------------------------------------------------
conn = agdb.connect()
try:
    cfg = agdb.get_config(conn)
    lock = agdb.get_state(conn, "cycle_lock")
finally:
    conn.close()

nxt = scheduler.next_run_time()
c1, c2, c3, c4 = st.columns(4)
c1.metric("Autonomy", "ON" if cfg.get("autonomy") else "OFF")
c2.metric("Cycle interval", f"{cfg.get('interval_hours', 6):g} h")
c3.metric("State", "running now" if lock else "idle")
c4.metric("Next scheduled cycle",
          nxt.strftime("%H:%M UTC") if nxt else "—")

# --- database totals --------------------------------------------------------
st.subheader("Shared database (same tables the MaterialsDatabase Space reads)")
conn = agdb.connect()
try:
    stats = agdb.table_stats(conn)
finally:
    conn.close()
sdf = pd.DataFrame(stats)
if sdf["rows"].notna().any():
    cols = st.columns(len(stats) + 1)
    total = int(sdf["rows"].fillna(0).sum())
    cols[0].metric("Total property rows", f"{total:,}")
    for i, row in enumerate(stats, start=1):
        cols[i].metric(row["table"],
                       f"{row['rows']:,}" if row["rows"] is not None else "?",
                       help=f"{row['ok']} ok / {row['flagged']} flagged · "
                            f"{row['materials']} materials")
else:
    st.info("Material tables not found — run `python pg_migrate.py --apply` "
            "once against the shared database (see README).")

# --- ingestion over time ----------------------------------------------------
hist = df_or_empty(
    "SELECT substring(extracted_at, 1, 10) AS day, count(*) AS rows_added "
    "FROM (SELECT extracted_at FROM \"Polymers\" WHERE extracted_at IS NOT NULL "
    "UNION ALL SELECT extracted_at FROM \"Fibers\" WHERE extracted_at IS NOT NULL "
    "UNION ALL SELECT extracted_at FROM \"Composites_materials\" "
    "WHERE extracted_at IS NOT NULL) t "
    "GROUP BY 1 ORDER BY 1")
if not hist.empty:
    st.subheader("Rows added per day")
    st.bar_chart(hist.set_index("day")["rows_added"])

# --- DOI registry / recent runs --------------------------------------------
left, right = st.columns(2)
with left:
    st.subheader("Latest papers harvested (by DOI)")
    doi_df = df_or_empty(
        "SELECT downloaded_at, doi, title, source, ingest_status, rows_inserted "
        "FROM agent_doi_seen ORDER BY downloaded_at DESC LIMIT 15")
    if doi_df.empty:
        st.caption("Nothing harvested yet — run a cycle from Run Control.")
    else:
        doi_df["doi"] = doi_df["doi"].map(
            lambda d: f"https://doi.org/{d}" if d else "")
        st.dataframe(
            doi_df,
            column_config={
                "doi": st.column_config.LinkColumn("DOI"),
                "downloaded_at": st.column_config.DatetimeColumn(
                    "Downloaded", format="MMM D, HH:mm"),
                "rows_inserted": st.column_config.NumberColumn("Rows"),
            },
            hide_index=True, width='stretch')

with right:
    st.subheader("Recent agent cycles")
    runs = df_or_empty(
        "SELECT id, started_at, trigger, status, downloaded, rows_inserted, "
        "rows_flagged, errors FROM agent_runs ORDER BY id DESC LIMIT 10")
    if runs.empty:
        st.caption("No cycles yet.")
    else:
        st.dataframe(
            runs,
            column_config={"started_at": st.column_config.DatetimeColumn(
                "Started", format="MMM D, HH:mm")},
            hide_index=True, width='stretch')

st.caption("The agent discovers open-access literature (OpenAlex → Unpaywall, "
           "arXiv), dedupes by DOI, downloads and validates PDFs, extracts "
           "grounded property data with Gemini, and publishes to the shared "
           "Postgres — flagged rows go to the Review Queue, never silently dropped.")
