"""AIM Composites — Autonomous Ingestion Agent Space.

Streamlit shell: navigation + one-time boot (schema, query seeding, background
scheduler). The agent itself lives in agent/orchestrator.py and keeps running
whether or not anyone is viewing the app.
"""
import logging

import streamlit as st

logging.basicConfig(level=logging.INFO,
                    format="%(asctime)s %(levelname)s %(name)s %(message)s")

st.set_page_config(
    page_title="AIM Autonomous Agent",
    page_icon="🤖",
    layout="wide",
)

from agent.ui_common import boot  # noqa: E402

boot()  # idempotent: agent schema, default queries, scheduler sync

pages = {
    "": [
        st.Page("page_files/Dashboard.py", title="Dashboard", icon="📊", default=True),
        st.Page("page_files/Run_Control.py", title="Run Control", icon="🎛️"),
        st.Page("page_files/Recently_Added.py", title="Recently Added", icon="🆕"),
        st.Page("page_files/Review_Queue.py", title="Review Queue", icon="🔍"),
        st.Page("page_files/Logs.py", title="Runs & Logs", icon="📜"),
    ]
}

st.navigation(pages, position="top").run()
