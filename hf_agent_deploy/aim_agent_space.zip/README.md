---
title: AIM Autonomous Ingestion Agent
emoji: 🤖
colorFrom: blue
colorTo: green
sdk: docker
app_port: 7860
pinned: true
short_description: Autonomous DOI-deduped literature harvesting for the AIM Composites Materials Database
---

# AIM Autonomous Ingestion Agent

An autonomous agent that continuously grows the **AIM Composites Materials
Database** — the same Postgres the
[MaterialsDatabase Space](https://huggingface.co/spaces/aim4composites/MaterialsDatabase)
serves — by harvesting open-access literature **with DOI provenance**:

```
        plan ─▶ discover ─▶ dedupe ─▶ download ─▶ ingest ─▶ report
                (OpenAlex,   (by DOI,   (validated  (Gemini →   (metrics,
                 arXiv,       URL, and    %PDF,      grounding,   run log,
                 Unpaywall)   sha256)     size caps) unit-norm,   query
                                                     status)      rotation)
```

* **discover** — query rotation over an editable frontier; OpenAlex (OA filter,
  DOI-native) with Unpaywall fallback, arXiv, optionally Semantic Scholar.
* **dedupe** — a durable `agent_doi_seen` registry: a paper already harvested
  (by DOI, then URL, then content sha256) is never downloaded twice.
* **download** — polite (rate-limited, robots-aware), magic-byte + PyMuPDF
  validated, size-bounded.
* **ingest** — `extraction.py` (grounded, unit-aware Gemini extraction, prompt
  v2.0) via `batch_ingest.process_pdf` with the `pg_mirror` Postgres backend:
  every value is grounded in the PDF text, unit-normalized (`value_si`,
  `unit_canonical`), classified, deduped at measurement grain, and inserted
  with a `status` — flagged rows are quarantined for review, never dropped.
* **report** — per-cycle metrics in `agent_runs` (dashboards + paper §8), event
  stream in `agent_events`, optional Gemini query expansion when yields dry up.

The graph runs on LangGraph; the agent loop runs in-process on an APScheduler
interval, so the Space works autonomously while it is up — no viewers needed.

## Pages

| Page | What it shows |
|---|---|
| **Dashboard** | agent status, DB totals, rows/day, latest DOIs, recent cycles |
| **Run Control** | autonomy on/off, interval, per-cycle budget, source toggles, query frontier editor, manual "run one cycle" |
| **Recently Added** | newest ingested documents with DOI links + verified-row counts |
| **Review Queue** | all `status != 'ok'` rows, CSV export, human promote-to-ok |
| **Runs & Logs** | cycle history with per-PDF results, full event stream |

## Deploy (≈5 minutes)

1. **Create the Space**: huggingface.co → New Space → owner `aim4composites`,
   name e.g. `AutonomousAgent`, SDK **Docker**, visibility your call.
2. **Push this folder** to it:
   ```bash
   git clone https://huggingface.co/spaces/aim4composites/AutonomousAgent
   cp -r <this folder>/* <this folder>/.streamlit <this folder>/.gitignore AutonomousAgent/
   cd AutonomousAgent && git add -A && git commit -m "Autonomous ingestion agent" && git push
   ```
   (or upload the files through the web UI — Files → Add file.)
3. **Set Space secrets** (Settings → Variables and secrets):

   | Secret | Value |
   |---|---|
   | `DB_HOST` / `DB_PORT` / `DB_NAME` / `DB_USER` / `DB_PASSWORD` | same values the MaterialsDatabase Space uses |
   | `GEMINI_API_KEY` | a **fresh** Gemini key (rotate the leaked ones!) |
   | `AGENT_ADMIN_PASSWORD` | password that unlocks Run Control / promote |
   | `CONTACT_EMAIL` *(variable, optional)* | polite-crawling contact for OpenAlex/Unpaywall |
   | `S2_API_KEY` *(optional)* | enables the Semantic Scholar source |

4. **One-time schema check**: the shared Postgres must already have the
   hardening columns + `sources` table (`python pg_migrate.py` dry-run, then
   `--apply`, from any machine with the DB env set). If the July pipeline runs
   already did this, there is nothing to do — the agent refuses to write until
   the schema is migrated, so it fails safe either way.
5. Open the Space → **Run Control** → unlock admin → *Run one cycle now* to
   smoke-test → toggle **Autonomous crawling** ON.

## Operations notes

* **Budgets**: per-cycle caps (default 5 PDFs) bound Gemini spend; a hard
  ceiling of 25 is compiled in. Cycle lock is durable and self-expiring, so
  overlapping schedules or container restarts can't double-run.
* **Sleep**: a free Space pauses after ~48 h without HTTP traffic. Options:
  visit it occasionally, add any uptime pinger, or upgrade the Space hardware
  to always-on. All state is in Postgres, so waking up resumes cleanly.
* **Ephemeral disk**: PDFs live under `/tmp` only until ingested; provenance
  (DOI, sha256, title, URL, query) is durable in `agent_doi_seen`.
* **Safety**: the agent never alters the shared tables' schema (that stays
  with `pg_migrate.py`); all agent bookkeeping is in namespaced `agent_*`
  tables; controls are password-gated; read-only without the password.

## Repo map

Vendored pipeline (single source of truth, unchanged from the project repo):
`extraction.py`, `batch_ingest.py`, `pdf_crawler.py`, `pg_mirror.py`,
`pg_migrate.py`, `migrate.py`, `generate_queries.py`.

Agent layer (new): `agent/` (orchestrator, scheduler, DB, config),
`app.py` + `page_files/` (Streamlit UI).
