# GitHub integration branch — how to push it

Contents: two commits on top of `main` (`f47dc69b`) of
`AIM-for-Composites/InDesDatabaseTool`, delivered two equivalent ways —
use whichever you prefer.

**Commit 1 — bug fixes** (the three blockers from the June review):
`DocToDB_eval_v2.py` Gemini `max_output_tokens` KeyError (dual-LLM was
silently GPT-only) · `Scheduler.py` crawler fired every 1 min instead of daily
· `Frontier.py` `sources.json` case bug (empty frontier on Linux).

**Commit 2 — `agent_space/`** + `INTEGRATION.md`: the full autonomous-agent
Hugging Face Space (same content as `aim_agent_space.zip`), versioned with the
team repo so the Space and the repo stay in sync.

## Option A — git bundle (preserves authorship + messages)

```bash
git clone https://github.com/AIM-for-Composites/InDesDatabaseTool.git
cd InDesDatabaseTool
git fetch ../integration-agent-space.bundle integration/agent-space:integration/agent-space
git push origin integration/agent-space
```

Then open a PR: `integration/agent-space` → `main` and tag Tejaswi + Abhijit.

## Option B — patches

```bash
cd InDesDatabaseTool
git checkout -b integration/agent-space
git am ../patches/*.patch
git push origin integration/agent-space
```

If `git am` complains (line-ending drift on Windows), use
`git am --3way ../patches/*.patch`.
